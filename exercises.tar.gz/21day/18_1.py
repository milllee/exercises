#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 18_1.py
# Create Time: 2017年04月16日 星期日 14时25分41秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''在python中创建了一个简单的堆栈结构
'''

class PyStack:                                      # 堆栈类
    def __init__(self, size = 20):
        self.stack = []                             # 堆栈列表
        self.size = size                            # 堆栈大小
        self.top = -1                               # 堆顶位置

    def setSize(self, size):                        # 设置堆栈大小
        self.size = size

    def push(self, element):                        # 元素进栈
        if self.isFull():
            raise StackException('PyStackOverflow') # 如果栈满则引发异常
        else:
            self.stack.append(element)
            self.top += 1

    def pop(self):                                  # 元素出栈
        if self.isEmpty():
            raise StackException('PyStackUnderflow')# 如果栈为空则引发异常
        else:
            element = self.stack[-1]
            self.top -= 1
            del self.stack[-1]
            return element

    def Top(self):                                  # 获取栈顶位置
        return self.top

    def empty(self):                                # 清除栈
        self.stack = []
        self.top = -1

    def isEmpty(self):                              # 是否为空栈
        if self.top == -1:
            return True
        else:
            return False

    def isFull(self):                               # 是否为满栈
        if self.top == self.size - 1:
            return True
        else:
            return False

class StackException(Exception):                    # 自定义异常类
    def __init__(self, data):
        self.data = data

    def __str__(self):
        return self.data

if __name__ == '__main__':
    stack = PyStack()                               # 创建栈
    for i in range(10):
        stack.push(i)                               # 元素进栈
    print(stack.Top())                              # 输出栈顶位置
    for i in range(8):
        print(stack.pop())                          # 元素出栈
    print(stack.isEmpty())                          # 是否为空栈
    stack.empty()                                   # 清空栈
    print(stack.isEmpty())
    for i in range(20):
        stack.push(i)                               # 栈满后添加会报错
    print(stack.isFull())
