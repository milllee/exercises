#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 17_1.py
# Create Time: 2017年06月06日 星期二 15时46分50秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''使用Flask框架简历的一个最简单的Web程序
'''

import flask                                    # 导入flask

app = flask.Flask(__name__)                     # 实例化主类Flask
@app.route('/')                                 # 装饰器(实现URL地址)
def helo():                                     # 定义业务函数
    return '你好，我是Flask！'                  # 返回字符串

if __name__ == '__main__':
    app.run('0.0.0.0', 8000)                    # 运行程序
