#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 7_2.py
# Create Time: 2017年05月11日 星期四 11时43分19秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''对于没运行时异常的程序，不论是否捕获异常，程序都会正常运行，但是如果程序中发生了运行时异常，
被捕获则程序运行不会中断，否则程序运行会中断退出
'''

def testTry(index, flag=False):
    stulst = ['John', 'Jenny', 'Tom']
    if flag:                            # flag为True时，捕获异常
        try:
            astu = stulst[index]
        except IndexError:
            print('IndexError')
        return 'Try Test Finished!'
    else:                               # flag为False时，不捕获异常
        astu = stulst[index]
        return 'No Try Test Finished'

if __name__ == '__main__':
    print('Right params testing start...')
    print(testTry(1, True))             # 不越界参数，捕获异常
    print(testTry(1, False))            # 不越界参数，不捕获异常
    print('Error params testing start...')
    print(testTry(4, True))             # 越界参数，捕获异常
    print(testTry(4, False))            # 越界参数，不捕获异常
