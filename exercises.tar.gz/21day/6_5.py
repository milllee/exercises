#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 6_5.py
# Create Time: 2017年05月10日 星期三 18时03分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''类中定义的类属性和实例属性的定义和使用

重要: 实例属性即同一个类的不同实例，其值是不相关联的，也不会互相影响的，定义时使用"self.属性名",调用时也使用它;
类属性则是同一个类的所有实例所共有的，直接在类体中独立定义，引用时要使用"类名.类变量名"形式来引用，只要是某个实例对其进行修改，就会影响其他的所有这个类的实例
'''

class Demo_Property:                    # 定义类
    class_name = "Demo_Property"        # 类属性

    def __init__(self, x=0):
        self.x = x                      # 实例属性

    def class_info(self):               # 输出信息的方法
        print('类变量值: {}'.format(Demo_Property.class_name))
        print('实例变量值: {}'.format(self.x))

    def chng(self, x):                  # 修改实例属性的方法
        self.x = x                      # 注意实例属性引用方式

    def chng_cn(self, name):            # 修改类属性的方法
        Demo_Property.class_name = name # 注意类属性引用方式

if __name__ == '__main__':
    dpa = Demo_Property()               # 实例化类
    dpb = Demo_Property()               # 实例化类
    print('初始化两个实例')
    dpa.class_info()
    dpb.class_info()
    print('修改实例变量')
    print('修改dpa实例变量')
    dpa.chng(3)
    dpa.class_info()
    dpb.class_info()
    print('修改dpb实例变量')
    dpb.chng(10)
    dpa.class_info()
    dpb.class_info()
    print('修改类变量')
    print('修改dpa类变量')
    dpa.chng_cn('dpa')
    dpa.class_info()
    dpb.class_info()
    print('修改dpb实例变量')
    dpb.chng_cn('dpb')
    dpa.class_info()
    dpb.class_info()
