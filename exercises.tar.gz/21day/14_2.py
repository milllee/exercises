#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_2.py
# Create Time: 2017年05月27日 星期六 16时15分40秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

import socket

HOST = 'localhost'
PORT = 10888
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
data = '你好'
while data:
    s.sendall(data.encode('utf-8'))
    data = s.recv(512)
    print('Receive from server:\n{}'.format(data.decode('utf-8')))
    data = input('输入一些信息:\n')
s.close()
