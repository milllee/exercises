#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_4.py
# Create Time: 2017年05月10日 星期三 15时42分54秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''带有两个具有默认值参数的函数
'''

def hello(hi='你好', name='Python'):
    print('{}, {}'.format(hi, name))

print('有一个参数("Jackson")调用时的输出:')
hello('Jackson')
print('有两个参数("哈哈", "Michael")调用时的输出:')
hello('哈哈', 'Michael')
