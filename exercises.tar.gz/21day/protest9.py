#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 15_8.1.py
# Create Time: 2017年06月1日 星期四 11时08分40秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
a = input()
a = a.split(' ')
a[0] = str(int(a[0]) + 1)
print(' '.join(a))
