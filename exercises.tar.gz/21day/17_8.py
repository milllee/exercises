#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_8.py
# Create Time: 2017年06月01日 星期四 04时36分43秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''使用静态文件，只要在模板文件中使用以下语句:
url_for('static', filename='.y.jpg')
它会生成一个网址/static/my.jpg，要求静态文件保存在当前目录的static文件夹下.
使用flask.render_template()来调用当前目录下的templates子目录中的HTML文件，其具体形式如下：
flask.render_template('name.html', name='name')，其中参数:
* name.html 是要返回页面内容的文件名；
* name 传递变量name的值为字符串'name'，供其在页面文件内容中输出相关信息。

使用独立HTML文件的URL服务，并在其中引用了服务器中的图片文件
'''

import flask

app = flask.Flask(__name__)

@app.route('/hello')
def helo():
    return flask.render_template('index.html')      # 渲染index.html文件

if __name__ == '__main__':
    app.run('0.0.0.0', 7890, debug=True)
# 对应的静态文件在static/test.jpg   templates/index.html
