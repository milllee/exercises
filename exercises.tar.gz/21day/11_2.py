#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 11_2.py
# Create Time: 2017年04月16日 星期日 02时06分39秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''演示fileinput模块的基本使用方法
'''

import fileinput

def demo_fileinput(name1, name2):
    with fileinput.input([name1, name2]) as lines:
        for line in lines:                          # 迭代处理两个文件
            print('总第{}行, 文件{}中第{}行: '.format(fileinput.lineno(), fileinput.filename(), fileinput.filelineno()))
            print(line.strip())

if __name__ == '__main__':
    demo_fileinput('fpa.txt', 'fpb.txt')
