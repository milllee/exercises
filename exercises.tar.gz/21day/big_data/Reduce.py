#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: Reduce.py
# Create Time: 2017年06月19日 星期一 17时07分36秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

import os, os.path, re

def Reduce(sourceFolder, targetFile):
    tempData = {}       # 缓存字典
    p_re = re.compile(r'(.*?)(\d{1,}$)', re.IGNORECASE) # 用正则表达式解析数据
    for root, dirs, files in os.walk(sourceFolder):
        for fil in files:
            if fil.endswith('_map.txt'):    # 以_map.txt结尾的文件
                sFile = open(os.path.abspath(os.path.join(root, fil)), 'r')
                dataLine = sFile.readline()

                while dataLine: # 有数据
                    subdata = p_re.findall(dataLine)    # 用空格分割数据
                    # print(subdata[0][0], ' ', subdata[0][1])
                    if subdata[0][0] in tempData:
                        tempData[subdata[0][0]] += int(subdata[0][1])
                    else:
                        tempData[subdata[0][0]] = int(subdata[0][1])
                    dataLine = sFile.readline()     # 读入下一行数据

                sFile.close()

    tList = []
    for key, value in sorted(tempData.items(), key = lambda k: k[1], reverse = True):
        tList.append(key + ' ' + str(value) + '\n')

    tFilename = os.path.join(sourceFolder, targetFile + '_reduce.txt')
    tFile = open(tFilename, 'a+')       # 创建小文件
    tFile.writelines(tList)             # 将列表保存到文件
    tFile.close()

if __name__ == '__main__':
    Reduce('access', 'access')
