#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 15_1.py
# Create Time: 2017年05月31日 星期三 16时52分36秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''定义一个thrfun函数,然后以线程方式来运行它,，并且每次运行传递不同的参数

两个子线程并行执行，分别计算出数的平方并输出，这两个子线程是交替进行的...
'''

import threading

def thrfun(x, y):
    for i in range(x, y):
        print(str(i*i) + ';')

if __name__ == '__main__':
    ta = threading.Thread(target=thrfun, args=(1, 6))
    tb = threading.Thread(target=thrfun, args=(16, 21))
    ta.start()
    tb.start()
