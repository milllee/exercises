#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_6.py
# Create Time: 2017年05月10日 星期三 16时08分08秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''同时有三种类型的参数的函数定义及调用
'''

def change_para_num(*tpl, a, b=0):
    print('tpl: {}'.format(tpl))
    print('a: {}'.format(a))
    print('b: {}'.format(b))

change_para_num(1, 2, 3, a=5)
change_para_num(1, 2, 3)    # 调用会出错，a变量没有默认值，也不能获取值
