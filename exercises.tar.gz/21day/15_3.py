#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 15_3.py
# Create Time: 2017年05月31日 星期三 17时36分49秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''join()函数的基本用法
'''

import threading
import time

def thrfun(x, y, thr=None):
    if thr:
        thr.join()
    else:
        time.sleep(1)
    for i in range(x, y):
        print(str(i * i) + ';')

if __name__ == '__main__':
    ta = threading.Thread(target=thrfun, args=(1, 6))
    tb = threading.Thread(target=thrfun, args=(16, 21, ta))
    ta.start()
    tb.start()
