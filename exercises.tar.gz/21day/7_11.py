#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 7_11.py
# Create Time: 2017年05月10日 星期三 01时27分01秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''交互模式下pdb模块调试函数实例
'''

import pdb

def sum(maxint):
    s = 0
    for i in range(maxint):
        s += i
    return s

pdb.runcall(sum, 10)
