#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 18_3.py
# Create Time: 2017年04月16日 星期日 15时35分09秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

G = ['G', []]               # 构造叶子G，树中每个元素都包括该元素和该元素的值的儿子列表组成
H = ['H', []]               # 构造叶子H
I = ['I', []]
K = ['K', []]
E = ['E', [G, H, I, K]]     # 构造 E 节点
D = ['D', []]
F = ['F', []]
A = ['A', [D, E]]
B = ['B', []]
C = ['C', [F]]
Root = ['Root', [A, B, C]]  # 构造树根
print(Root)
