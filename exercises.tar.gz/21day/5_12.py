#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_12.py
# Create Time: 2017年05月10日 星期三 16时54分49秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''一个简单的程序，在函数内外都有同一个名称的变量而不影响
'''

def myfun():
    a = 0       # 函数内声明并初始化变量a为整数
    a += 3      # 修改a的值
    print('函数内a: {}'.format(a))  # 输出函数内a的值

a = 'external'      # 全局作用域内a声明并初始化

print('全局作用域a: {}'.format(a))
myfun()         # 调用函数
print('全局作用域a: {}'.format(a))
