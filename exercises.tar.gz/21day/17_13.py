#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_13.py
# Create Time: 2017年06月01日 星期四 08时03分33秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''获取POST请求中参数的实例
'''

import tornado.ioloop
import tornado.web

html_txt = '''
<!DOCTYPE html>
<html>
    <body>
        <h2>收到GET请求</h2>
        <form method='post'>                # 指明表单请求的方法
        <input type='text' name='name' placeholder='请输入你的姓名' />
        <input type='submit' value='发送POST请求' />
        </form>
    </body>
</html>
'''

class MainHdl(tornado.web.RequestHandler):
    def get(self):
        self.write(html_txt)

    def post(self):
        name = self.get_argument('name', default='匿名', strip=True)
        self.write('你的姓名是: {}'.format(name))

app = tornado.web.Application([
    (r'/get', MainHdl),
    ], debug=True)

if __name__ == '__main__':
    app.listen(9988)
    tornado.ioloop.IOLoop.instance().start()
