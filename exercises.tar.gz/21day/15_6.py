#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 15_6.py
# Create Time: 2017年05月31日 星期三 18时01分09秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''两个线程通过Event来唤醒对方，模拟人物对话

线程间同步可以用threading模块中的条件变量、队列等来进行，可以使用threading模块中的Event对象
'''

import threading, time

class myThread_a(threading.Thread):
    def run(self):
        evt.wait()                                  # wait([timeout])方法会使当前线程阻塞至标志为True
        print(self.name, ':Good morning!')
        evt.clear()
        time.sleep(1)
        evt.set()                                   # set()方法会将Event设置为True
        time.sleep(1)
        evt.wait()
        print(self.name, ':I\'m fine, thank you.')

class myThread_b(threading.Thread):
    def run(self):
        print(self.name, ':Good morning!')
        evt.set()
        time.sleep(1)
        evt.wait()
        print(self.name, ':How are you?')
        evt.clear()                                 # clear()方法会将Event重置为False
        time.sleep(1)
        evt.set()

evt = threading.Event()

def main():
    John = myThread_a()
    John.name = 'John'
    Smith = myThread_b()
    Smith.name = 'Smith'
    John.start()
    Smith.start()

if __name__ == '__main__':
    main()
