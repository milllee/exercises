#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 15_8.py
# Create Time: 2017年06月01日 星期四 11时00分00秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''Popen类初始化参数如下：
class Popen(args, bufsize=-1, executable=None, stdin=None, stdout=None, stderr=None,
            preexec_fn=None, close_fds=True, shell=False, cwd=None, env=None, universal_newlines=False,
            startupinfo=None, creationflags=0, restore_signals=True, start_new_session=False,pass_fds=() )
Popen 对象具有一下常用方法:
* poll()                    检查子进程是否结束
* wait(timeout=None)        等待子进程结束
* communicate(input=None, timeout=None) 用户和子进程交互：发送标准输入数据，返回由标准输出和错误输出构成的元组

Popen 常用属性：
* pid                       子进程的pid
* returncode                子进程的退出码(None时子进程未退出)

使用Popen产生子进程的方式执行python源代码
'''

import subprocess

prcs = subprocess.Popen(['python3', 'protest8.py'],
                        stdout = subprocess.PIPE,
                        stdin = subprocess.PIPE,
                        stderr = subprocess.PIPE,
                        universal_newlines = True,
                        shell = True)
prcs.communicate('These strings are from stdin.')
print('subprocess pid: {}'.format(prcs.pid))
print('\nSTDOUT:')
print(str(prcs.communicate()[0]))
print('STDERR:')
print(prcs.communicate()[1])
