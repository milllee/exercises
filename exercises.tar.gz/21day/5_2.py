#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_2.py
# Create Time: 2017年05月10日 星期三 15时32分30秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''函数定义和调用
'''

def tpl_sum(T):
    result = 0
    for i in T:
        result += i
    return result

print('(1, 2, 3, 4)元组中元素的和为: {}'.format(tpl_sum((1, 2, 3, 4))))
print('[1, 2, 3, 4]列表中元素的和为: {}'.format(tpl_sum([1, 2, 3, 4])))
print('[2.7, 2, 5.8]列表中元素的和为: {}'.format(tpl_sum([2.7, 2, 5.8])))
print('[1, 2, 'ab']列表中元素的和为: {}'.format(tpl_sum([1, 2, 'ab']))) # 会出错
