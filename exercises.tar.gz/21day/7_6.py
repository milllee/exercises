#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 7_6.py
# Create Time: 2017年05月11日 星期四 15时07分16秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''程序中使用了代码抛出异常，因为没有捕获该异常，所以程序运行会中断，导致后面的代码不能运行
'''

def testRaise():
    for i in range(5):
        if i == 3:
            raise NameError
        print(i)
    print('end...')

if __name__ == '__main__':
    testRaise()
