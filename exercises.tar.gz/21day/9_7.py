#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 9_7.py
# Create Time: 2017年05月10日 星期三 05时04分32秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''一个装饰器及其使用的例子
'''

def abc(myclass):                       # 定义类装饰器
    class InnerClass:                   # 定义内嵌类
        def __init__(self, z=0):
            self.z = 0
            self.wrapper = myclass()    # 实例化被装饰的类

        def position(self):
            self.wrapper.position()
            print('z axis: {}'.format(self.z))

    return InnerClass                   # 返回新定义的类

@abc                                    # 应用装饰器
class coordination:                     # 定义普通的类
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def position(self):
        print('x axis: {}'.format(self.x))
        print('y axis: {}'.format(self.y))

if __name__ == '__main__':
    coor = coordination()               # 实例化被装饰的类
    coor.position()                     # 调用方法position()
