#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: protest.py
# Create Time: 2017年06月01日 星期四 10时57分43秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

print('Hello, World!')
