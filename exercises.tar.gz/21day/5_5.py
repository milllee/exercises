#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_5.py
# Create Time: 2017年05月10日 星期三 16时03分24秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''自定义一个带星号的参数的函数实例
'''

def change_para_num(*tpl):
    print(type(tpl))
    print(tpl)

change_para_num(1)
change_para_num(1, 2, 3)
# 两次调用第一行输出类型为tuple, 第一次调用时只有一个参数,元组也只有一个值
# 第二次调用时有3个参数，全部收集到了tpl变量中
