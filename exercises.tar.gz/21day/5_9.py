#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_9.py
# Create Time: 2017年05月10日 星期三 16时27分39秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''拆解元组的函数调用
'''

def mysum(a, b):
    return a + b

print('拆解元组调用: ')
print(mysum(*(3, 4)))  # 调用时拆解元组作为位置参数
print('拆解字典调用: ')
print(mysum(**{'a': 3, 'b': 4})) # 调用时拆解字典为关键字参数
