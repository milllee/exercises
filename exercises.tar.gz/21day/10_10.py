#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_10.py
# Create Time: 2017年05月10日 星期三 07时25分57秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''鸭子类型的使用实例
'''

class Duck:
    def __init__(self, name='duck'):
        self.name = name

    def quack(self):
        print('嘎嘎嘎...')

class Cat:
    def __init__(self, name='cat'):
        self.name = name

    def quack(self):
        print('喵喵喵...')

class Tree:
    def __init__(self, name='tree'):
        self.name = name

def duck_demo(obj):
    obj.quack

if __name__ == '__main__':
    duck = Duck()
    cat = Cat()
    tree = Tree()
    duck_demo(duck)             # 调用参数鸭子类型
    duck_demo(cat)              # 调用参数鸭子类型
    duck_demo(tree)             # 会引发错误
