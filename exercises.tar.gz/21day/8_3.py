#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 8_3.py
# Create Time: 2017年05月10日 星期三 03时17分48秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

import pcka

print('输出pcka包中的变量name: {}'.format(pcka.name))   # 调用并输出包pcka中变量name

print('调用pcka包中的函数:', end='')
pcka.pck_test_fun()                     # 调用包pcka中的函数
