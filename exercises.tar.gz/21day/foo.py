#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: foo.py
# Create Time: 2017年05月10日 星期三 05时17分28秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

name = 'Foo module'                     # 定义全局变量name

def foo_fun():                          # 定义函数foo_fun()
    print('函数foo_fun()')
    print('变量name: {}'.format(name))  # 输出全局变量name
