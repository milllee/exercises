#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 6_7.py
# Create Time: 2017年05月09日 星期二 22时02分03秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''类的继承
'''

class Ant:
    def __init__(self, x=0, y=0, color='black'):
        self.x = x
        self.y = y
        self.color = color

    def crawl(self, x, y):  # 定义方法，爬行
        self.x = x
        self.y = y
        print('爬行...')
        self.info()

    def info(self):
        print('当前位置: {}, {}'.format(self.x, self.y))

    def attack(self):       # 定义方法，模拟攻击
        print('用嘴咬')

class FlyAnt(Ant):          # 定义FlyAnt类，继承Ant
    def attack(self):       # 修改行为，攻击方法不同
        print('用尾针')

    def fly(self, x, y):    # 定义方法，模拟飞行
        print('飞行')
        self.x = x
        self.y = y
        self.info()

if __name__ == '__main__':
    flyant = FlyAnt(color='red')    # 实例化类
    flyant.crawl(3, 5)              # 调用方法，模拟爬行
    flyant.fly(10, 14)              # 调用方法，模拟飞行
    flyant.attack()                 # 调用方法，模拟攻击
