#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_2.py
# Create Time: 2017年05月10日 星期三 05时27分46秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''一个嵌套函数的例子
'''

x = 14                              # 全局变量x

def foo():                          # 定义函数(嵌套的外层函数)
    x = 3
    def bar():                      # 定义函数(嵌套的内层函数)
        print('x is {}'.format(x))  # 引用变量x(实际引用的是嵌套的外层函数中的x)
    bar()                           # 调用嵌套的内层函数

if __name__ == '__main__':
    foo()
