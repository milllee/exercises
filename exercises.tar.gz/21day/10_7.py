#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_7.py
# Create Time: 2017年05月10日 星期三 06时13分46秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''通过setattr()修改对象属性的实例
'''

class DemoClass:                                # 定义一个用于演示的类
    class_val = 3
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
        self.info()

    def info(self):
        print('类属性class_val: {}'.format(DemoClass.class_val))
        print('实例属性x: {}'.format(self.x))
        print('实例属性y: {}'.format(self.y))

if __name__ == '__main__':
    dc = DemoClass()                            # 实例化类
    if hasattr(DemoClass, 'class_val'):
        setattr(DemoClass, 'class_val', 1000)   # 设置类属性的值
    if hasattr(dc, 'x'):
        setattr(dc, 'x', 'xxxxxxxxxxxxx')       # 设置实例发生的值
    if hasattr(dc, 'y'):
        setattr(dc, 'y', 'yyyyyyyyyyyyy')
    dc.info()
    if not hasattr(dc, 'z'):
        setattr(dc, 'z', 'zzzzzzzzzzzzzz')      # 添加并设置实例属性的值
    print('添加的属性z: {}'.format(dc.z))
