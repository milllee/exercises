#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_7.py
# Create Time: 2017年06月01日 星期四 04时23分18秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''使用session会话同样可以完成17_6.py的cookie功能

一个使用session跟踪用户的实例
'''

import flask

html_txt = '''
<!DOCTYPE html>
<html>
    <body>
        <h2>收到GET请求</h2>
        <a href='/get_info'>获取会话信息</a>
    </body>
</html>
'''

app = flask.Flask(__name__)

@app.route('/set_info/<name>')
def set_cks(name):
    name = name if name else 'anonymous'
    flask.session['name'] = name                                # 设置session
    return html_txt

@app.route('/get_info')
def get_cks():
    name = 'name' in flask.session and flask.session['name']    # 获取session
    if name:
        return '获取的会话消息是: ' + name
    else:
        return '没有相应会话消息'

if __name__ == '__main__':
    app.secret_key = 'afadff#$#5dgfddgssgfgsfgr4$T^%^'          # 设置cookie密钥
    app.run('0.0.0.0', 8000, debug=True)
