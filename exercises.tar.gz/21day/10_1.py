#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_1.py
# Create Time: 2017年05月10日 星期三 05时16分45秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''函数与其全局命名空间关系的实例
'''

from foo import foo_fun                 # 导入foo模块中的函数foo_fun

name = 'Current module'                 # 定义全局变量name

def bar():                              # 定义普通函数bar()
    print('当前模块中函数bar: ')
    print('变量name: {}'.format(name))  # 输出全局变量name

def call_foo_fun(fun):                  # 定义调用传入函数作为参数的函数
    fun()                               # 调用传入的函数

if __name__ == '__main__':
    bar()                               # 调用本模块中定义的函数bar()
    print()
    foo_fun()                           # 调用从模块foo中导入的函数foo_fun()
    print()
    call_foo_fun(foo_fun)
