#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_8.py
# Create Time: 2017年05月10日 星期三 16时17分23秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''带有大量默认参数的函数及其调用
'''

def cube(name, **nature):
    all_nature = {'x': 1,
                'y': 1,
                'z': 1,
                'color': 'white',
                'weight': 1}
    all_nature.update(nature)
    print(name, '立方体的属性: ')
    print('体积: {}'.format(all_nature['x'] * all_nature['y'] * all_nature['z']))
    print('颜色: {}'.format(all_nature['color']))
    print('重量: {}'.format(all_nature['weight']))

cube('first')                                   # 只给出必要的参数的调用
cube('second', y=3, color='red')                # 提供部分可选参数
cube('third', z=2, color='green', weight=10)    # 提供部分可选参数
