#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_6.py
# Create Time: 2017年06月01日 星期四 03时56分10秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''获取cookie可以使用: flask.request.cookie.get('name')
设置cookie则需要使用make_reponse对象:
resp = make_response(content)                    # content 返回页面内容
resp.set_cookie('username', 'the username')     # 设置名为username的cookie

一个使用cookie跟踪用户的实例
'''

import flask

html_txt = '''                                  # 定义设置cookie页面内容
<!DOCTYPE html>
<html>
    <body>
        <h2>收到GET请求</h2>
        <a href='/get_info'>获取cookie信息</a>
    </body>
</html>
'''

app = flask.Flask(__name__)

@app.route('/set_info/<name>')                  # 从URL中获取参数URL装饰器
def set_cks(name):
    name = name if name else 'anonymous'
    resp = flask.make_response(html_txt)         # 构造响应对象
    resp.set_cookie('name', name)               # 设置cookie
    return resp

@app.route('/get_info')
def get_cks():
    name = flask.request.cookies.get('name')    # 获取cookie信息
    return '获取的cookie信息是:' + name         # 返回带cookie信息的页面内容

if __name__ == '__main__':
    app.run('0.0.0.0', 8888, debug=True)
