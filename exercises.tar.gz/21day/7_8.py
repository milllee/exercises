#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 7_8.py
# Create Time: 2017年05月11日 星期四 15时13分05秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''程序中使用了assert抛出异常，同时捕获了该异常
'''

def testAssert():
    for i in range(4):
        try:
            assert i < 2
        except AssertionError:
            print('Raise a AssertionError')
        print(i)
    print('end...')

if __name__ == '__main__':
    testAssert()
