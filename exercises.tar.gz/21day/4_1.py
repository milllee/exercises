#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 4_1.py
# Create Time: 2017年05月10日 星期三 14时36分14秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''最简单的if结构语句
'''

def my_abs(n):
    if n < 0:
        n = -n
    return n

asd = my_abs(-4)
print(asd)
