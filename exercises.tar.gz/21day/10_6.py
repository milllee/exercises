#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_6.py
# Create Time: 2017年05月10日 星期三 06时08分27秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''通过装饰器contextmanager实现的一个上下文管理器
'''

import contextlib

@contextlib.contextmanager
def my_mgr(s, e):
    print(s)
    yield s + ' ' + e           # yield后的表达式值即为as后变量的值
    print(e)

if __name__ == '__main__':
    with my_mgr('start', 'end') as val:
        print(val)
