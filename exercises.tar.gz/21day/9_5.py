#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 9_5.py
# Create Time: 2017年05月10日 星期三 04时45分43秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''一个简单的生产者与消费者变成模型
'''

def consumer():                     # 定义一个消费者模型(生成器协程)
    print('等待接收处理任务...')
    while True:
        data = (yield)
        print('收到任务: {}'.format(data))  # 模拟接收并处理任务
                                            # (此处可以执行函数调用来完成相关任务)
def productor():                            # 定义一个生产者模型
    c = consumer()
    c.__next__()
    for i in range(3):
        print('发送一个任务...任务id: {}'.format(i))
        c.send('任务{}'.format(i))

if __name__ == '__main__':
    productor()
