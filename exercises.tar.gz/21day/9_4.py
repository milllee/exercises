#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 9_4.py
# Create Time: 2017年05月10日 星期三 04时36分50秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''一个可以接收调用者传来的值并重新初始化生成器的生成器的值
'''

def myYield(n):                     # 定义一个生成器函数
    while n > 0:
        rcv = yield n               # rcv用来接收调用者传来的值
        n -= 1
        if rcv is not None:         # rcv不为None就重置n为rcv
            n = rcv

if __name__ == '__main__':
    my_yield = myYield(3)           # 初始化生成器
    print(my_yield.__next__())
    print(my_yield.__next__())
    print('传给生成器一个值，重新初始化生成器')
    print(my_yield.send(10))
    print(my_yield.__next__())
