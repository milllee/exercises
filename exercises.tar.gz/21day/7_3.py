#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 7_3.py
# Create Time: 2017年05月11日 星期四 11时55分08秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''运用finally语句块来确保文件使用后能关闭该文件
'''

def testTryFinally(index):
    stulst = ['John', 'Jenny', 'Tom']
    af = open('my.txt', 'wt+')
    try:
        af.write(stulst[index])
    except:
        pass
    finally:
        af.close()                  # 无论是否产生异常，都关闭文件
        print('File had been closed')

if __name__ == '__main__':
    print('No IndexError...')
    testTryFinally(1)               # 无越界异常，关闭文件
    print('IndexError')
    testTryFinally(4)               # 有越界异常，也关闭文件
