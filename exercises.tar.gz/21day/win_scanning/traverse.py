#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: traverse.py
# Create Time: 2017年06月19日 星期一 15时26分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''遍历某个目录下的所有目录和文件，此例使用递归方式'''

import os, os.path

def traverse(pathname):
    for item in os.listdir(pathname):
        fullitem = os.path.join(pathname, item)
        print(fullitem)
        if os.path.isdir(fullitem):     # 判断是否为目录
            traverse(fullitem)

traverse('/root')
