#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: trav_walk.py
# Create Time: 2017年06月19日 星期一 15时23分35秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''遍历某个目录下的所有文件(不包括文件夹)'''

import os, os.path

def trav_walk(pathname):
    for root, dirs, files in os.walk(pathname):
        for fil in files:
            fname = os.path.abspath(os.path.join(root, fil))
            print(fname)

trav_walk('/root')
