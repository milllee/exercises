#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 17_4.py
# Create Time: 2017年06月06日 星期二 16时47分24秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''通过URL也是可以传递参数的，通过URL传递参数的方法是直接将数据放入URL中，然后在服务器端进行获取
Flask中获取URL参数要在URL装饰器和业务函数中分别进行定义或处理，URL变量规则有一下两种形式(URL装饰器中的URL字符串写法):
    /hello/<name>           # 获取形如"/hello/wangfei" URL中参数“wangfei”给name变量
    /hello/<int: id>        # 获取"/hello/3" URL中参数"3"并自动转换为整数3给id变量
    要获取和处理URL中传递来的参数，就要在对应的业务函数的参数列表中列出变量名，其形式如下:
    @app.route("/hello/<name>")
    def get_url_param(name):
        pass
    这样，在业务函数get_url_param()中就可以引用这个变量值，并进一步使用URL中传来的参数

使用这个参数的URL装饰器的实例
'''

import flask                                # 导入flask

app = flask.Flask(__name__)                 # 实例化主类Flask

@app.route('/hello/<name>')
def helo(name):                             # 定义业务函数，列出参数name
    return '你好，' + name + '!'            # 返回请求的页面内容

if __name__ == '__main__':
    app.run('0.0.0.0', 9999)                # 运行程序
