#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_3.py
# Create Time: 2017年05月10日 星期三 15时39分18秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''一个带默认参数的函数
'''

def hello(name='python'):
    print('你好, {}'.format(name))

print('无参数调用时的输出:')
hello()
print('有参数调用时的输出:')
hello('JAVA')
