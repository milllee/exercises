#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_14.py
# Create Time: 2017年06月01日 星期四 08时20分33秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''Tornado框架提供了直接操纵cookie和安全cookie的方法，安全的cookie就是存储在客户端的cookie是经过加密的，
客户端只能查看到加密后的数据，使用cookie和安全cookie的基本原型方法如下:
set_cookie('name', value)           # 设置cookie
get_cookie('name')                  # 获取cookie值
set_secure_cookie('name', value)    # 设置安全cookie值
get_secure_cookie('name')           # 获取安全cookie值
clear_cookie('name')                # 清除名为name的cookie值
clear_all_cookie()                  # 清除所有cookie
(使用安全cookie，必须为Application类提供cookie_secret参数，以给出加密的密钥)

一个在不同页面设置与获取cookie值的实例
'''

import tornado.ioloop
import tornado.web

class ScookHdl(tornado.web.RequestHandler):
    def get(self):
        odn_cookie = tornado.escape.url_escape('未加密COOKIE串')            # URL编码
        self.set_cookie('odn_cookie', odn_cookie)                           # 设置一般cookie
        self.set_secure_cookie('scr_cookie', 'SCURE_COOKIE')                # 设置安全cookie
        self.write('<a href="/gcook">查看设置的COOKIE</a>')

class GcookHdl(tornado.web.RequestHandler):
    def get(self):
        odn_cookie = self.get_cookie('odn_cookie')                          # 获取一般cookie值
        odn_cookie = tornado.escape.url_unescape(odn_cookie)                # 反URL编码
        scr_cookie = self.get_secure_cookie('scr_cookie').decode('utf-8')   # 获取安全cookie值
        self.write('普通COOKIE: {}, 安全COOKIE: {}'.format(odn_cookie, scr_cookie))

app = tornado.web.Application([
    (r'/scook', ScookHdl),
    (r'/gcook', GcookHdl),
    ], cookie_secret = 'abcddddkdk##$$34323sdDsdfdsf#23')

if __name__ == '__main__':
    app.listen(9998)
    tornado.ioloop.IOLoop.instance().start()
