#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: protest8.py
# Create Time: 2017年06月01日 星期四 11时20分21秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

s = input('输入一个名字: ')
print('hello, {}'.format(s))
print(a)
