#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_11.py
# Create Time: 2017年05月10日 星期三 16时48分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''使用列表作为默认参数时出现的“陷阱”
'''

#def myfun(lst=[]):
#    lst.append('abc')
#    print(lst)
def myfun(lst=None):
    if lst is None:
        lst = []
    lst.append('abc')
    print(lst)

myfun()
myfun()
myfun()
