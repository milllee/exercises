#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 6_4.py
# Create Time: 2017年05月10日 星期三 17时43分05秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''在类中调用自身的方法和全局函数的实例
'''

def coord_chng(x, y):               # 定义一个全局函数，模拟坐标值变换
    return (abs(x), abs(y))         # 将x, y值求绝对值后返回

class Ant:                          # 定义一个Ant类
    def __init__(self, x=0, y=0):   # 定义一个构造方法
        self.x = x
        self.y = y
        self.disp_point()           # 构造函数中调用类中的方法disp_point()

    def move(self, x, y):           # 定义一个方法move()
        x, y = coord_chng(x, y)     # 调用全局函数，坐标变换
        self.edit_point(x, y)       # 调用类中的方法edit_point()
        self.disp_point()           # 调用类中的方法disp_point()

    def edit_point(self, x, y):     # 定义一个方法
        self.x += x
        self.y += y

    def disp_point(self):           # 定义一个方法
        print('当前位置: {} {}'.format(self.x, self.y))

if __name__ == '__main__':
    ant_a = Ant()                   # 实例化Ant()类
    ant_a.move(2, 4)                # 调用ant_a实例的方法move()
    ant_a.move(-9, 6)               # 调用ant_a实例的方法move()
