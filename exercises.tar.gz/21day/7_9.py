#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 7_9.py
# Create Time: 2017年05月11日 星期四 15时19分57秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''程序自定义了一个异常类，并用代码引发异常，如需要异常类带有一定的提示信息，可重载__init__和__str__这两个方法
'''

class RangeError(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return self.value

if __name__ == '__main__':
    raise RangeError('Range Error')
