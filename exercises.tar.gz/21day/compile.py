#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: compile.py
# Create Time: 2017年05月10日 星期三 02时34分25秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

import py_compile.py;

py_compile.compile('8_2.py', '8_2.pyc');
