#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: pcka/__init__.py
# Create Time: 2017年05月10日 星期三 03时13分32秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''一个包结构的程序
'''

name = 'pcka'                               # 定义变量name
print('__init__.py中输出{}'.format(name))   # 输出变量name的值

def pck_test_fun():                         # 定义函数pck_test_fun()
    print('pcka包中的方法pck_test_fun')
