#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 7_7.py
# Create Time: 2017年05月11日 星期四 15时07分16秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''程序中使用了代码抛出异常，同事捕获了该异常，所以程序运行不会中断
'''

def testRaise():
    for i in range(5):
        try:
            if i == 3:
                raise NameError
        except NameError:
            print('Raise a NameError')
        print(i)
    print('end...')

if __name__ == '__main__':
    testRaise()
