#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 9_2.py
# Create Time: 2017年05月10日 星期三 04时11分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''第二种原型的使用方法
'''

class Counter:                      # 定义用于计算的数
    def __init__(self, x=0):        # 定义构造函数，初始化实例属性x
        self.x = x

counter = Counter()                 # 实例化类Counter

def used_iter():                    # 定义用户iter()函数的函数
    counter.x += 2                  # 修改计数类中的实例属性的值
    return counter.x

for i in iter(used_iter, 8):        # 迭代iter()函数产生的迭代器
    print('本次遍历的数值: {}'.format(i))
