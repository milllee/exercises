#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 7_13.py
# Create Time: 2017年05月10日 星期三 01时45分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''使用doctest模块的testfile函数进行基本的单元测试
'''

import pdb

def grade(sum):
    if sum > 90:
        return '优'
    if sum > 80:
        return '良'
    if sum > 60:
        return '中'
    if sum < 60:
        return '差'
