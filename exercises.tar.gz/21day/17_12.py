#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_12.py
# Create Time: 2017年06月01日 星期四 06时28分35秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''在GET方法中获取URL中参数的基本实例
'''

import tornado.ioloop
import tornado.web

class MainHdl(tornado.web.RequestHandler):
    def get(self, uid='0'):                             # 方法中有uid参数，获取URL参数
        self.write('你好，你的UID是: {}'.format(uid))

app = tornado.web.Application([
    (r'/([0-9]+)', MainHdl),                            # 正则表达式URL，捕获参数
    ], debug=True)

if __name__ == '__main__':
    app.listen(9999)
    tornado.ioloop.IOLoop.instance().start()
