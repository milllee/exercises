#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 9_3.py
# Create Time: 2017年05月10日 星期三 04时28分38秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''自定义生成器函数及其使用的实例
'''

def myYield(n):                     # 定义一个生成器(函数)
    while n > 0:
        print('开始生成...:')
        yield n                     # yield语句，用于返回给调用者其后表达式的值
        print('完成一次...')
        n -= 1

if __name__ == '__main__':
    for i in myYield(4):            # for 语句遍历生成器
        print('遍历得到的值:{}'.format(i))
    print()
    my_yield = myYield(3)           # 生成一个生成对象
    print('已经实例化生成器对象')
    my_yield.__next__()             # 手动调用其特殊方法，获取序列中的一个值
    print('第二次调用__next__()方法:')
    my_yield.__next__()
