#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_9.py
# Create Time: 2017年06月01日 星期四 04时55分51秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''使用flask框架编写上传文件的服务器端与处理GET或POST参数具有相似的地方，客户端上传的文件相关信息会保存到flask.request.files对象中，
通过这个对象可以获取上传来的文件名和文件对象，再调用文件对象的save()来将文件保存到指定的目录中即可.

一个文件上传的基本例子
'''

import flask

app = flask.Flask(__name__)

@app.route('/upload', methods=['GET', 'POST'])          # 请求的GET、POST映射同一函数
def upload():
    if flask.request.method == 'GET':
        return flask.render_template('upload.html')     # 请求方法为POST时返回上传页面
    else:
#        file = flask.request.files['file']              # 获取文件对象
        file = 'file' in flask.request.files and flask.request.files['file']
        if file:                                        # 如果文件不是空
            file.save(file.filename)                    # 保存文件(以传来的文件名)
            return '上传成功!'

if __name__ == '__main__':
    app.run('0.0.0.0', 6789, debug=True)
# templates/upload.html
