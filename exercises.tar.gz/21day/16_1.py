#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 16_1.py
# Create Time: 2017年06月01日 星期四 14时45分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''运用sqlite3模块来操作SQLite3数据库的基本方法
'''

import sqlite3                                          # 导入标准库sqlite3
import random                                           # 导入标准库random

src = 'abcdefghijklmnopqrstuvwxyz'                      # 定义随机生成字符串中的所有字符

def get_str(x, y):                                      # 定义生成字符串函数(指定长度介于x, y间)
    str_sum = random.randint(x, y)                      # 产生x, y间一个随机整数
    astr = ''
    for i in range(str_sum):
        astr += random.choice(src)                      # 随机选取src中字符并累加
    return astr

def output():                                           # 定义输出数据库表中所有记录函数
    cur.execute('select * from mytab')                  # 执行查询
    for sid, name, ps in cur:                           # 遍历记录
        print(sid, ' ', name, ' ', ps)                  # 输出记录

def output_all():                                       # 定义输出数据库表中所有记录函数
    cur.execute('select * from mytab')
    for item in cur.fetchall():                         # 使用fetchall()函数
        print(item)

def get_data_list(n):                                   # 定义生成记录列表数据的函数
    res = []
    for i in range(n):
        res.append((get_str(2, 4), get_str(8, 12)))
    return res

if __name__ == '__main__':
    print('建立连接...')
    con = sqlite3.connect(':memory:')                   # 建立连接(使用内存中的数据库)
    print('建立游标...')
    cur = con.cursor()                                  # 获取游标
    print('创建一张表mytab...')
    cur.execute('create table mytab(id integer primary key autoincrement not null, name text, passwd text)')    # 创建数据库表mytab
    print('插入一条记录...')
    cur.execute('insert into mytab (name, passwd) values(?, ?)', (get_str(2, 4), get_str(8, 12)))               # 插入一条记录
    print('显示所有记录...')
    output()                                            # 显示所有记录
    print('批量插入多条记录...')
    cur.executemany('insert into mytab (name, passwd) values(?, ?)', get_data_list(3))                          # 插入多条记录
    print('显示所有记录...')
    output_all()                                        # 显示所有记录
    print('删除一条记录...')
    cur.execute('delete from mytab where id=?', (3,))   # 删除一条记录
    print('显示所有记录...')
    output()                                            # 显示所有记录
    cur.close()                                         # 关闭游标
    con.close()                                         # 关闭连接
