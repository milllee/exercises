#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 18_6.py
# Create Time: 2017年05月10日 星期三 10时11分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''使用字典的方式构建一棵树的有向图，并搜索图中的路径
'''

def searchGraph(graph, start, end):             # 搜索树
    results = []
    generatePath(graph, [start], end, results)  # 生成路径
    results.sort(key=lambda x: len(x))          # 按路径长度排序
    return results

def generatePath(graph, path, end, results):    # 生成路径
    state = path[-1]
    if state == end:
        results.append(path)
    else:
        for arc in graph[state]:
            if arc not in path:
                generatePath(graph, path + [arc], end, results)

if __name__ == '__main__':
    Graph = {'A': ['B', 'C', 'D'],              # 构建树
            'B': ['E'],
            'C': ['D', 'F'],
            'D': ['B', 'E', 'G'],
            'E': [],
            'F': ['D', 'G'],
            'G': ['E']}
r = searchGraph(Graph, 'A', 'D')                # 搜索A到D的所有路径
print('*' * 25)
print('     path A to D')
print('*' * 25)
for i in r:
    print(i)
r = searchGraph(Graph, 'A', 'E')                # 搜索A到E的所有路径
print('*' * 25)
print('     path A to E')
print('*' * 25)
for i in r:
    print(i)
r = searchGraph(Graph, 'C', 'E')                # 搜索C到E的所有路径
print('*' * 25)
print('     path C to E')
print('*' * 25)
for i in r:
    print(i)
