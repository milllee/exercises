#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_9.py
# Create Time: 2017年05月10日 星期三 07时14分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''自定义的类来实现类的特别的运算方式

=================类的特殊方法==========================
方法名:                 描      述
__init__                构造函数，生成对象时调用
__del__                 析构函数，释放对象时调用
__add__                 加运算
__mul__                 乘运算
__cmp__                 比较运算
__repr__                打印，转换
__setitem__             按照索引赋值
__getitem__             按照索引获取值
__len__                 获得长度
__call__                函数调用
'''

class Book:                                     # 定义一个类Book
    def __init__(self, name='Python 从入门到放弃'):
        self.name = name

    def __add__(self, obj):                     # 重载这个方式，实现类相加
        return self.name + ' add ' + obj.name   # 得到书名相加

    def __len__(self):                          # 重载这个方法，使求其长度
        return len(self.name)                   # 得到书名的字符长度

if __name__ == '__main__':
    booka = Book()                              # 实例化类
    bookb = Book('Java 从入门到放弃')
    print('len(booka): {}'.format(len(booka)))  # 求其长度并输出
    print('len(bookb): {}'.format(len(bookb)))
    print(booka + bookb)                        # 两个类相加
