#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 6_8.py
# Create Time: 2017年05月09日 星期二 22时13分16秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''多重继承
'''

class PrntA:                        # 定义父类PrntA
    namea = 'PrntA'
    def set_value(self, a):
        self.a = a

    def set_namea(self, namea):
        PrntA.set_namea = namea

    def info(self):
        print('PrntA: {}, {}'.format(PrntA.namea, self.a))

class PrntB:                        # 定义父类PrntB
    nameb = 'PrntB'
    def set_nameb(self, nameb):
        PrntA.nameb = nameb

    def info(self):
        print('PrntB: {}'.format(PrntB.nameb))

class Sub(PrntA, PrntB):            # 定义子类Sub，先后继承了PrntA,PrntB
    pass

class Sub2(PrntB, PrntA):           # 定义子类Sub，先后继承了PrntB,PrntA
    pass

class Sub3(PrntA, PrntB):           # 定义子类Sub，先后继承了PrntA,PrntB
    def info(self):                 # 修改了方法info()
        PrntA.info(self)
        PrntB.info(self)

if __name__ == '__main__':
    print('使用第一个子类:')
    sub = Sub()
    sub.set_value('aaaa')
    sub.info()
    sub.set_nameb('BBBB')
    sub.info()
    print('使用第二个子类:')
    sub2 = Sub2()
    sub2.set_value('cccc')
    sub2.info()
    sub2.set_nameb('DDDD')
    sub2.info()
    print('使用第三个子类:')
    sub3 = Sub3()
    sub3.set_value('eeee')
    sub3.info()
    sub3.set_nameb('FFFF')
    sub3.info()
