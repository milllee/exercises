#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_7.py
# Create Time: 2017年05月10日 星期三 16时14分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''定义了收集关键字参数的示例
'''

def change_para_dct(a, b=0, **adct):
    print('adct: {}'.format(adct))
    print('a: {}'.format(a))
    print('b: {}'.format(b))

change_para_dct(1, k=3, b=2, c=5)
