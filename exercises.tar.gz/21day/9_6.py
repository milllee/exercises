#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 9_6.py
# Create Time: 2017年05月10日 星期三 04时53分48秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''自定义一个装饰器并用来装饰自定义的函数
'''

def abc(fun):                       # 定义一个装饰器abc
    def wrapper(*args, **kwargs):   # 定义包装器函数
        print('开始运行...')
        fun(*args, **kwargs)        # 调用被装饰函数
        print('运行结束!')
    return wrapper                  # 返回包装器函数

@abc                                # 装饰函数语句
def demo_decoration(x):             # 定义普通函数，被装饰器装饰
    a = []
    for i in range(x):
        a.append(i)
    print(a)

@abc
def hello(name):                    # 定义普通函数(被装饰器装饰)
    print('Hello ', name)

if __name__ == '__main__':
    demo_decoration(5)              # 调用被装饰器装饰的函数
    print()
    hello('John')                   # 调用被装饰器装饰的函数
