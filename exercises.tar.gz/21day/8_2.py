#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 8_2.py
# Create Time: 2017年05月10日 星期三 02时27分33秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

import module_test          # 导入模块

module_test.m_t_pr()        # 调用导入模块的函数
print('使用module_test模块中的变量：{}'.format(module_test.name))   # 使用导入模块中的变量
