#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 17_10.py
# Create Time: 2017年06月07日 星期三 17时26分41秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''一个使用数据库保存用户注册信息和验证登录的简单实例，各请求方法的代码如下:
'''

import os, flask
from flask import g, request, render_template, session, redirect, url_for
from sqlite3 import connect

DBNAME = 'test.db'

app = flask.Flask(__name__)
app.secret_key = 'dfadff#$#5dgfddgssgfgsfgr4$T^%^'

@app.before_request                                                                         # 应用装饰器，每个请求 开始 时运行被装饰函数
def before_request():
    g.db = connect(DBNAME)                                                                  # 连接sqlite3数据库

@app.teardown_request                                                                       # 应用装饰器，每个请求 退出 时运行被装饰函数
def teardown_request(e):
    db = getattr(g, 'db', None)
    if db:
        db.close()                                                                          # 关闭数据库连接
    g.db.close()

@app.route('/')                                                                             # 本网站的主页(index)
def index():
    if 'username' in session:                                                               # 会话中有用户名信息，用户已登录，显示用户信息、注销
        return '你好，' + session['username'] + '<p><a href="/logout">注销</a></p>'
    else:                                                                                   # 会话中没有用户名，用户未登陆，显示登陆和注册
        return '<a href="/login">登录</a>, <a href="/signup">注册</a>'

@app.route('/signup', methods=['GET', 'POST'])                                              # 用户注册URL
def signup():                                                                               # 用户注册的业务函数
    if request.method == 'GET':                                                             # GET请求，返回注册页面
        return render_template('signup.html')
    else:                                                                                   # POST请求，进行注册操作
        name = 'name' in request.form and request.form['name']
        passwd = 'passwd' in request.form and request.form['passwd']
        if name and passwd:                                                                 # 校验用户名和密码不能为空
            cur = g.db.cursor()                                                             # 获取数据库的游标
            cur.execute('insert into user (name, passwd) values (?, ?)', (name, passwd))    # 向数据库中插入用户注册信息
            cur.connection.commit()                                                         # 提交保存插入数据
            cur.close()                                                                     # 关闭游标
            session['username'] = name                                                      # 设置会话
            return redirect(url_for('index'))                                               # 转向主页
        else:
            return redirect(url_for('signup'))                                              # 注册信息不全，返回注册页面

@app.route('/login', methods=['GET', 'POST'])                                               # 用户登录的URL
def login():                                                                                # 用户登录的业务函数
    if request.method == 'GET':                                                             # GET请求
        return render_template('login.html')                                                # 返回登陆页面
    else:                                                                                   # POST请求
        name = 'name' in request.form and request.form['name']
        passwd = 'passwd' in request.form and request.form['passwd']
        if name and passwd:                                                                 # 校验用户名密码不为空
            cur = g.db.cursor()                                                             # 一下查询数据库，验证用户名和密码
            cur.execute('select * from user where name=?', (name,))
            res = cur.fetchone()
            if res and res[1] == passwd:
                session['username'] = name                                                  # 成功验证，设置会话
                return redirect(url_for('index'))                                           # 返回主页
            else:
                return '登录失败'
        else:
            return '参数不全'

@app.route('/logout')                                                                       # 用户注销的URL
def logout():                                                                               # 用户注销的业务函数
    session.pop('username', None)
    return redirect(url_for('index'))                                                       # 返回主页

def init_db():
    if not os.path.exists(DBNAME):
        cur = connect(DBNAME).cursor()
        cur.execute('create table user (name text, passwd text)')
        cur.connection.commit()
        print('数据库初始化完成!')

if __name__ == '__main__':
    init_db()
    app.run('0.0.0.0', 8899, debug=True)
