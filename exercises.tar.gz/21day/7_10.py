#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 7_10.py
# Create Time: 2017年05月10日 星期三 01时15分47秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''交互模式下使用pdb模块调试

帮助:
完整命令                简写命令        描述
args                        a           打印当前函数的参数
clear                       cl          清除断点
break                       b           设置断点
condition                   无          设置条件断点
continue                c或者cont       继续运行，知道遇到断点或者程序结束
disable                     无          禁用断点
enable                      无          启用断点
ignore                      无          忽略断点
jump                        j           跳转到指定行数运行
list                        l           列出程序清单
next                        n           执行下条语句，遇到函数不进入其内部
p                           p           打印变量值，也可以用print
quit                        q           退出pdb
return                      r           一直运行到函数返回
tbreak                      无          设置临时断点，断点只中断一次
step                        s           执行下一条语句，遇到函数进入其内部
where                       w           查看所在的位置
！                          无          在pdb中执行语句
'''

import pdb

pdb.run('''
for i in range(5):
    print(i)
''')
