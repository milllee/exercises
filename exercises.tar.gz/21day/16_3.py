#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 16_3.py
# Create Time: 2017年06月01日 星期四 16时53分10秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''使用第三方库pymongo操作MongoDB数据库的实例
'''

from pymongo import MongoClient                 # 导入pymongo数据库
import random

src = 'abcdefghijklmnopqrstuvwxyz'

def get_str(x, y):
    str_sum = random.randint(x, y)
    astr = ''
    for i in range(str_sum):
        astr += random.choice(src)
    return astr

def get_data_list(n):
    res = []
    for i in range(n):
        res.append({'name': get_str(2,4), 'passwd': get_str(8,12)})
    return res

if __name__ == '__main__':
    print('建立连接...')
    stus = MongoClient().test.stu               # 一条语句实现连接到集合
    print('插入一条记录...')
    stus.insert({'name': get_str(2, 4), 'passwd': get_str(8, 12)})
    print('显示所有记录...')
    stu = stus.find()                           # 显示刚才插入的一个文档
    print(stu)
    print('批量插入多条记录...')
    stus.insert(get_data_list(3))               # 批量插入生成的文档
    print('显示所有记录...')
    for stu in stus.find():
        print(stu)
    print('更新一条记录...')
    name = input('请输入记录的name: ')          # 输入要更改的文档的name
    stus.update({'name': name}, {'$set': {'name': 'aaaa'}}) # 更新
    print('显示所有记录...')
    for stu in stus.find():                     # 显示所有文档以验证更改
        print(stu)
    print('删除一条记录...')
    name = input('请输入要删除记录的name: ')    # 驶入要删除文档的name
    stus.remove({'name': name})
    print('显示所有记录...')
    for stu in stus.find():
        print(stu)
    print('删除所有记录...')
    stus.drop()
