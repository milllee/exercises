#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 7_12.py
# Create Time: 2017年05月10日 星期三 01时32分38秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''使用doctest模块的testmod函数进行基本的单元测试
'''

import pdb

def grade(sum):
    """
    >>> grade(100)
    '优秀'
    >>> grade(80)
    '良好'
    >>> grade(65)
    '合格'
    >>> grade(10)
    '不合格'
    """
    if sum > 90:
        return '优'
    if sum > 80:
        return '良'
    if sum > 60:
        return '中'
    if sum < 60:
        return '差'

if __name__ == '__main__':
    import doctest
    doctest.testmod()
