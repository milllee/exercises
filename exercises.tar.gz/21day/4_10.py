#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 4_10.py
# Create Time: 2017年05月10日 星期三 14时53分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''计算并输出有用户指定的两个整数之间所有素数的程序
'''

x = int(input('输入第一个数字: ')), int(input('输入第二个数字: '))
x1 = min(x)
x2 = max(x)
for i in range(x1, x2 + 1):
    for j in range(2, i):
        if i % j == 0:
            break
    else:
        print('{}是素数'.format(i))
