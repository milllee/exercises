#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 3_1.py
# Create Time: 2017年05月10日 星期三 14时07分23秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

mystr = 'Beautiful is better than ugly.'
print('source string is: {}'.format(mystr))
print('swapcase demo\t{}'.format(mystr.swapcase()))
print('upper demo\t{}'.format(mystr.upper()))
print('lower demo\t{}'.format(mystr.lower()))
print('title demo\t{}'.format(mystr.title()))
print('istitle demo\t{}'.format(mystr.istitle()))
print('islower demo\t{}'.format(mystr.islower()))
print('capitalize demo\t{}'.format(mystr.capitalize()))
print('find "u" demo\t{}'.format(mystr.find('u')))
print('count "a" demo\t{}'.format(mystr.count('a')))
print('split demo\t{}'.format(mystr.split(' ')))
print('join demo\t{}'.format(','.join(mystr.split(' '))))
print('len demo\t{}'.format(len(mystr)))
