#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 11_4.py
# Create Time: 2017年04月16日 星期日 03时44分02秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''批量重命名
'''

import os
perfix = 'python'                   # perfix为重命名后的文件起始字符
length = 2                          # length为除去perfix后，文件名要达到的长度
base = 1                            # 文件名的起始数
foramt = 'mdb'                      # 文件的后缀名

def PadLeft(str, num, padstr):      # 函数PadLeft将文件名补全到指定长度
    stringlength = len(str)         # str为要补全的字符
    n = num - stringlength          # num为要达到的长度
    if n >= 0:
        str = padstr * n + str      # padstr未达到长度所添加的字符
    return str

# 为了避免误操作，这里先提示用户
print('在{}目录下的文件将要被改名:'.format(os.getcwd()))
all_files = os.listdir(os.getcwd())
print([ f for f in all_files if os.path.isfile(f) ])    # 输出当前目录下的所有文件名
input = input('继续按[y]: ')                            # 获取用户输入
if input.lower() != 'y':                                # 判断用户输入，以决定是否执行重命名操作
    exit()
filenames = os.listdir(os.curdir)                       # 获得当前目录的内容
i = base - 1
for filename in filenames:                              # 遍历目录中的内容，进行重命名操作
    i += 1
    if filename != 'rename.py' and os.path.isfile(filename):
        name = str(i)                                   # 将i转换成字符
        name = PadLeft(name, length, '0')               # 将name补全到指定长度
        t = filename.split('.')                         # 分割文件名，以检查其是否是所要修改的类型
        m = len(t)
        if format == '':                                # 如果未指定文件类型，则更改当面目录中的所有文件
            os.rename(filename, perfix+name+'.'+t[m-1])
        else:                                           # 否则只修改指定类型
            if t[m-1] == format:
                os.rename(filename, perfix+name+'.'+t[m-1])
            else:
                i -= 1                                  # 保证i连续
    else:
        i -= 1                                          # 保证i连续

all_files = os.listdir(os.getcwd())
print([ f for f in all_files if os.path.isfile(f) ])
