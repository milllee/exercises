#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_16.py
# Create Time: 2017年06月07日 星期三 23时02分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''Tornado框架也支持在网站的页面中直接使用静态的资源文件，如图片、JS脚本、CSS样式表等，如使用静态文件资源，需要在Application类初始化时提供'static_path'参数
'''

import tornado.ioloop
import tornado.web

class SttHdl(tornado.web.RequestHandler):
    def get(self):
        self.write("<img src='/static/torn.jpg' />")

app = tornado.web.Application([
    (r'/stt', SttHdl),
    ], static_path='./static')                          # 提供了static_path参数

if __name__ == '__main__':
    app.listen(9988)
    tornado.ioloop.IOLoop.instance().start()
