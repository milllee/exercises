#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_9.py
# Create Time: 2017年05月31日 星期三 14时01分54秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''使用smtplib库发送邮件
'''

import smtplib, email

chst = email.charset.Charset(input_charset='utf-8')
header = ('From: {}\nTo: {}\nSubject: {}\n\n'.format('angel5213@126.com', '252343465@qq.com', chst.header_encode('Python smtplib测试！')))
body = '你好！'
email_conn = header.encode('utf-8') + body.encode('utf-8')
smtp = smtplib.SMTP('smtp.126.com')
smtp.login('angel5213@126.com', 'lml19860719')
smtp.sendmail('angel5213@126.com', '252343465@qq.com', email_conn)
smtp.quit()
