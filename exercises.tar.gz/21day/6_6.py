#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 6_6.py
# Create Time: 2017年05月09日 星期二 21时50分06秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''同时定义了类方法和静态方法的类
'''

class DemoMthd:
    @staticmethod               # 静态方法装饰器
    def static_mthd():          # 静态类定义
        print('调用了静态方法')

    @classmethod                # 类方法装饰器
    def class_mthd(cls):        # 类方法定义，带默认参数cls
        print('调用了类方法')

if __name__ == '__main__':
    DemoMthd.static_mthd()      # 未实例化类，通过类名调用静态方法
    DemoMthd.class_mthd()       # 未实例化类，通过类名调用类方法
    dm = DemoMthd()             # 实例化类
    dm.static_mthd()            # 通过类实例调用静态方法
    dm.class_mthd()             # 通过类实例调用类方法
