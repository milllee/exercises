#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_11.py
# Create Time: 2017年06月01日 星期四 06时16分51秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''一个使用Tornado框架编写的最基本服务器程序
'''

import tornado.ioloop
import tornado.web

class MainHdl(tornado.web.RequestHandler):          # 自定义类
    def get(self):                                  # 回应GET请求方法
        self.write('你好，我是Tornado！')

app = tornado.web.Application([
    (r'/', MainHdl),                                # URL映射列表(可有多条)
    ], debug=True)

if __name__ == '__main__':
    app.listen(8888)                                # 服务器监听8888端口
    tornado.ioloop.IOLoop.instance().start()        # 启动服务器
