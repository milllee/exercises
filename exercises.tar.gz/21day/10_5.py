#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_5.py
# Create Time: 2017年05月10日 星期三 05时57分48秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''自定义一个上下文管理器及其使用方法
'''

class FileMgr:                          # 实现上下文管理协议方法的类
    def __init__(self, filename):       # 构造函数(初始化文件名)
        self.filename = filename
        self.f = None

    def __enter__(self):                # 定义协议方法
        self.f = open(self.filename, encoding='utf-8')
        return self.f                   # 返回资源引用

    def __exit__(self, t, v, tb):       # 定义协议方法
        if self.f:
            self.f.close()              # 释放文件资源

if __name__ == '__main__':
    with FileMgr('10_4.py') as f:       # 用上下文管理器直接打开文件
        for line in f.readlines():      # 并返回文件资源引用供操作
            print(line, end='')
