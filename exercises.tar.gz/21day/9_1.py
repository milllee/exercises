#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 9_1.py
# Create Time: 2017年05月10日 星期三 04时12分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''自定义一个迭代器的演示实例
'''

class MyIterator:                       # 自定义类迭代器类MyIterator

    def __init__(self, x=2, xmax=100):  # 定义构造方法，初始化实例属性
        self.__mul, self.__x = x, x
        self.__xmax = xmax

    def __iter__(self):                 # 定义迭代器协议方法，返回类本身
        return self

    def __next__(self):                 # 定义迭代器协议方法
        if self.__x and self.__x != 1:
            self.__mul *= self.__x
            if self.__mul <= self.__xmax:
                return self.__mul       # 返回值
            else:
                raise StopIteration     # 引StopIteration错误
        else:
            raise StopIteration

if __name__ == '__main__':
    myiter = MyIterator()
    for i in myiter:
        print('迭代的数据元素为：{}'.format(i))
        
