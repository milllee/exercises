#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_4.py
# Create Time: 2017年05月10日 星期三 05时41分06秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''可以用来进行泛型函数定义的实例
'''

def line(a, b):
    def aline(x):
        return a * x + b        # 泛型函数中可以使用不同的a、b值
    return aline

if __name__ == '__main__':
    line23 = line(2, 3)         # a、b值分别为2、3的一次函数
    line50 = line(5, 0)         # a、b值分别为5、0的一次函数
    print(line23(4))            # x为4时的第一种类型函数值
    print(line50(2))            # x为2时的第二种类型函数值
