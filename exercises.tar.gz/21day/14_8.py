#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_8.py
# Create Time: 2017年05月27日 星期六 18时02分53秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''使用poplib库来检查指定邮件中的最新10封邮件的主题及发信人
'''

from poplib import POP3
import re, email, email.header

def decode_email_content(msg_src, names):
    msg = email.message_from_bytes(msg_src)
    result = {}
    for name in names:
        content = msg.get(name)
        info = email.header.decode_header(content)
        if info[0][1]:
            if info[0][1].find('unknown-') == -1:
                result[name] = info[0][0].decode(info[0][1])
            else:
                try:
                    result[name] = info[0][0].decode('gbk')
                except:
                    result[name] = info[0][0].decode('utf-8')
        else:
            result[name] = info[0][0]
    return result

if __name__ == '__main__':
#    pp = POP3('pop3.163.com')
#    pp.user('miller5213@163.com')
#    pp.pass_('~!miller5213')
    pp = POP3('pop3.126.com')
    pp.user('angel5213@126.com')
    pp.pass_('lml19860719')
    total, totalnum = pp.stat()
    print(total, totalnum)
    for i in range(total-10, total):
        hinfo, msgs, octet = pp.top(i+1, 0)
        b = b''
        for msg in msgs:
            b += msg+b'\n'
        items = decode_email_content(b, ['subject', 'from'])
        print(items['subject'], '\nFrom:', items['from'])
        print()
    pp.close()
