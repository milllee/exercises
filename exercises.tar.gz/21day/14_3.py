#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_3.py
# Create Time: 2017年05月27日 星期六 16时34分13秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''udp Server
'''

import socket

HOST = ''
PORT = 10999
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind((HOST, PORT))
data = True
while data:
    data, address = s.recvfrom(1024)
    if data == b'bye':
        break
    print('Receive String: {}'.format(data.decode('utf-8')))
    s.sendto(data, address)
s.close()
