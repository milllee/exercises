#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: module_test.py
# Create Time: 2017年05月10日 星期三 02时21分08秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''自己编写一个模块，然后导入并调用其中函数
'''

print('导入的测试模块的输出:')              # 被导入时会被执行，输出信息

name = 'module_test'
def m_t_pr():
    print('模块module_test中m_t_pr()函数')
