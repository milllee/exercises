#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 15_5.py
# Create Time: 2017年05月31日 星期三 17时51分39秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''RLock的使用
'''

import threading
import time

class myThread(threading.Thread):
    def run(self):
        global x
        lock.acquire()
        for _ in range(3):
            x += 10
        time.sleep(1)
        print(x)
        lock.release()

x = 0
lock = threading.RLock()

def main():
    thrs = []
    for _ in range(5):
        thrs.append(myThread())
    for item in thrs:
        item.start()

if __name__ == '__main__':
    main()
