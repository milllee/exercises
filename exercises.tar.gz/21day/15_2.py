#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 15_2.py
# Create Time: 2017年05月31日 星期三 16时58分17秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''预定义一个函数，并以线程方式运行
'''

import threading

class myThread(threading.Thread):
    def __init__(self, mynum):
        super().__init__()
        self.mynum = mynum

    def run(self):
        for i in range(self.mynum, self.mynum + 5):
            print(str(i*i) + ';')

if __name__ == '__main__':
    ma = myThread(1)
    mb = myThread(16)
    ma.start()
    mb.start()
