#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 17_3.py
# Create Time: 2017年06月06日 星期二 16时09分03秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''GET请求一般是知己在浏览器地址栏中输入URL或单击连接产生的请求方式；
POST请求一般由提交表单时根据指定的请求方法POST，而产生的对Web服务器的请求

使用这个参数的URL装饰器的实例
'''

import flask                                # 导入flask

html_txt = '''                              # HTML页面字符串(GET请求的页面代码)
<!DOCTYPE html>
<html>
    <body>
        <h2>收到GET请求</h2>
        <form method='post'>                # 指定请求方法为POST
        <input type='submit' value='发送POST请求' />
        </form>
    </body>
</html>
'''

app = flask.Flask(__name__)                 # 实例化主类Flask
# 一下装饰器说明URL为'/hello'的请求，不论是'GET'还是'POST'方法，都映射到该函数
@app.route('/hello', methods=['GET', 'POST'])
def helo():                                 # 定义业务函数
    if flask.request.method == 'GET':       # 判断收到的请求是否为GET
        return html_txt                     # 返回GET请求的页面内容
    else:                                   # 否则收到的是POST请求
        return '收到POST请求，我还是Flask！'# 返回POST请求的页面内容

if __name__ == '__main__':
    app.run('0.0.0.0', 9000)                # 运行程序
