#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 7_4.py
# Create Time: 2017年05月11日 星期四 14时51分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''程序中若捕获所有异常，则无论运行引发了什么异常，程序都不会中断
'''

def testTryAll(index, i):
    stulst = ['John', 'Jenny', 'Tom']
    try:
        print(len(stulst[index]) / i)
    except:                         # 捕获所有异常
        print('Error')

if __name__ == '__main__':
    print('Try all ... Right')
    testTryAll(1, 2)                # 正常输出结果
    print('Try all ... Error')
    testTryAll(1, 0)                # 发生除0异常
    print('Try all ... two Error')
    testTryAll(4, 0)                # 越界异常、除0异常同时发生
