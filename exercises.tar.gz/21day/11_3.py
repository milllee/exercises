#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 11_3.py
# Create Time: 2017年04月16日 星期日 02时36分28秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''由文件名批量获取姓名和考号
'''

import os

filenames = []                                              # 所有文件名的存放列表
for a, b, files in os.walk('test'):                         # 获取当前目录下test目录中的所有文件
    if files:
        filenames.append([ file[:-4] for file in files ])   # 扩展名为3个字母

fname = 'testexam'                                          # 指定生成电子表格的文件名
i = 0
for files in filenames:
    f = open(fname + str(i) + '.xls', 'w')                  # 打开指定的文件
    for name in files:
        f.write(name[-2:] + '\t' + name[:-2] + '\n')        # 写入姓名和考号
    f.close()                                               # 关闭文件
    i += 1
print('成功生成')
