#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_7.py
# Create Time: 2017年05月27日 星期六 17时53分14秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''用用http.client.HTTPConnection对象访问网站
'''

from http.client import HTTPConnection

mc = HTTPConnection('www.baidu.com:80')
mc.request('GET', '/')
res = mc.getresponse()
print(res.status, res.reason)
print(res.read().decode('utf-8'))
