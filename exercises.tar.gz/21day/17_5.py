#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_5.py
# Create Time: 2017年06月01日 星期四 02时24分46秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''客户端与服务端传递参数的主要方式还是使用GET或POST参数传递，Flask也提供了简单的参数获取方法
    获取GET请求参数的基本方式是调用flask.request.args对象的get()方法，形式如下:
        flask.request.args.get(name)        # name 为参数名称
    如果是POST请求的参数，需要使用flask.request的form字典对象来获取，调用形式如下:
        flask.request.form['name']          # name 为参数名称
但用这种方法获取的参数名不存在时会报400错误请求页面，因此如果要使用这种方法来获取参数时，可以使用短if语句或逻辑运算形式:
    name = flask.request.form['name'] if 'name' in flask.request.form else None
    name = 'name' in flask.request.form and flask.request.form['name']
    第一种形式是根据'name' in flask.request.form判断结果来确定值，即form字典中有'name'键时，就获取它，否则结果为None
    第二种形式是采用Python语言的逻辑运算的特点实现的，即'name' in flask.request.form为False时，整个结果为False；如果后面为True，
会返回第二个表达式

获取POST请求参数的一个实例
'''

import flask

html_txt = '''
<!DOCTYPE html>
<html>
    <body>
        <h2>收到GET请求</h2>
        <form method='post'>
        <input type='text', name='name', placeholder='请输入你的姓名' />
        <input type='submit', value='发送POST请求' />
        </form>
    </body>
</html>
'''

app = flask.Flask(__name__)

@app.route('/hello', methods=['GET', 'POST'])
def helo():
    if flask.request.method == 'GET':
        return html_txt
    else:
        # 获取参数name的值
        name = 'name' in flask.request.form and flask.request.form['name']
        # name = flask.request.form['name'] if 'name' in flask.request.form else None
        if name:
            return '你是: ' + name + '!'
        else:
            return '你没有输入姓名!'

if __name__ == '__main__':
    app.run('0.0.0.0', 7777, debug=True)
