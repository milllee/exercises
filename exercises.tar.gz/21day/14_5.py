#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_5.py
# Create Time: 2017年05月27日 星期六 16时55分43秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

import socketserver

HOST = 'localhost'
PORT = 10888
class MyTCPHandler(socketserver.StreamRequestHandler):
    def handle(self):
        while True:
            data = self.request.recv(1024)
            if not data:
                Server.shutdown()
                break
            print('Receive Data: {}'.format(data.decode('utf-8')))
            self.request.send(data)
        return

if __name__ == '__main__':
    Server = socketserver.TCPServer((HOST, PORT), MyTCPHandler)
    Server.serve_forever()
