#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 7_5.py
# Create Time: 2017年05月11日 星期四 15时00分49秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''程序中捕获了部分异常，当程序运行时引发了不能被捕获的异常时，仍然会中断
'''

def testTryOne(index, i):
    stulst = ['John', 'Jenny', 'Tom']
    try:
        print(len(stulst[index]) / i)
    except IndexError:
        print('Error')

if __name__ == '__main__':
    print('Try one ... Right')
    testTryOne(1, 2)            # 正常输出结果
    print('Try one ... Error')
    testTryOne(4, 2)            # 发生越界异常被捕获，程序不会中断
    print('Try one ... one Error')
    testTryOne(1, 0)            # 发生除0异常，未捕获，程序中断，有错误提示
