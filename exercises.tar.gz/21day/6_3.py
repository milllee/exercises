#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 6_3.py
# Create Time: 2017年05月10日 星期三 17时33分55秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''一个定义了构造方法的类
'''

class DemoInit:
    def __init__(self, x, y=0): # 定义构造方法,具有两个初始化
        self.x = x
        self.y = y

    def mycacl(self):           # 定义应用初始化数据的方法
        return self.x + self.y

dia = DemoInit(3)               # 用一个参数实例化类
print('调用mycacl方法的结果1: ')
print(dia.mycacl())

dib = DemoInit(3, 7)            # 用两个参数实例化类
print('调用mycacl方法的结果2: ')
print(dib.mycacl())
