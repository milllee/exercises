#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 11_1.py
# Create Time: 2017年04月16日 星期日 01时54分58秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''一个处理文件中数据的例子
'''

with open('python.txt', 'w') as f:
    for i in range(1, 101):
        f.write('{}\n'.format(i))

def file_hd1(name='python.txt'):                    # 定义一个文件数据处理函数
    with open(name) as f:                           # 打开文件
        res = 0                                     # 累加器变量
        i = 0                                       # 计算读取的行数
        for line in f:                              # 迭代文件中的行
            i += 1
            line = line.strip()
            print('第{}行的数据为: {}'.format(line.strip(), line))
            res += int(line)                        # 累加数据

        print('这些数的和为: {}'.format(res))

if __name__ == '__main__':
    file_hd1()                                      # 调用函数
