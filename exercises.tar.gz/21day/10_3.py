#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 10_3.py
# Create Time: 2017年05月10日 星期三 05时32分51秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''一个可以延迟求值得实例
'''

def delay_fun(x, y):                        # 定义一个可以延迟求值的函数
    def caculator():                        # 内部嵌套的函数
        return x + y                        # 直接返回要求的值
    return caculator                        # 返回内部嵌套的函数对象

if __name__ == '__main__':
    print('返回一个求和的函数，并不求和')
    msum = delay_fun(3, 4)                  # 调用外层函数，并不计算，实际返回一个函数对象
    print()
    print('调用并求和')
    print(msum())                           # 实际求值的调用
