#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 8_1.py
# Create Time: 2017年05月10日 星期三 02时11分30秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''三种导入方式的使用方法
'''

import math             # 直接导入math模块
from math import sqrt   # 只导入math模块的sqrt()函数，可直接使用
import math as shuxue   # 导入math模块并重命名为shuxue

print('调用math.sqrt:\t\t{}'.format(math.sqrt(2)))    # 直接导入方式的调用
print('直接调用sqrt:\t\t{}'.format(sqrt(2)))          # 调用仅导入的函数
print('调用shuxue.sqrt:\t{}'.format(shuxue.sqrt(2)))# 调用重命名
