#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_6.py
# Create Time: 2017年05月27日 星期六 17时06分59秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''使用urlopen()在百度搜索关键词得到第一页链接
'''

from urllib.request import urlopen
from urllib.parse import urlencode
import re

wd = input('输入一个要搜索的关键字: ')
wd = urlencode({'wd': wd})
url = 'http://www.baidu.com/s?' + wd
page = urlopen(url).read()
content = (page.decode('utf-8')).replace("\n", "").replace("\t", "")
title = re.findall(r'<h3 class="t".*?h3>', content)
title = [item[item.find('href =') +6: item.find('target =')] for item in title]
title = [item.replace(' ', '').replace('"', '') for item in title]
for item in title:
    print(item)
