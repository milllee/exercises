#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 4_8.py
# Create Time: 2017年05月10日 星期三 14时50分23秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''用for循环遍历字典
'''

adct = {'apple': 15, 'banana': 20, 'pear': 35}
for key, value in adct.items():
    print(key, value)

for key in adct.keys():
    print(key)

for value in adct.values():
    print(value)
