#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_1.py
# Create Time: 2017年05月27日 星期六 16时08分40秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''14_1.py为服务端，14_2.py为客户端，服务端监听10888端口，等待接受客户端消息
'''

import socket

HOST = ''
PORT = 10888
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)
conn, addr = s.accept()
print('Client\'s Address: ', addr)
while True:
    data = conn.recv(1024)
    if not data:
        break
    print('Receive Data: {}'.format(data.decode('utf-8')))
    conn.send(data)
conn.close()
