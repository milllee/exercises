#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 6_1.py
# Create Time: 2017年05月10日 星期三 17时19分18秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''一个简单的定义与实例化
'''

class MyClass:              # 定义一个类
    '''MyClass help.'''     # 该类只有一个说明信息

myclass = MyClass()         # 将自定义类MyClass实例化,名称为myclass
print('输出类说明: ')
print(myclass.__doc__)      # 输出类实例myclass的属性__doc__的值
print('显示类帮助信息: ')
help(myclass)               # 输出类的帮助信息
