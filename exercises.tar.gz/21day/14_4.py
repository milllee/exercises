#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 14_4.py
# Create Time: 2017年05月27日 星期六 16时38分27秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''udp Client
'''

import socket

HOST = 'localhost'
PORT = 10999
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
data = '你好！'
while data:
    s.sendto(data.encode('utf-8'), (HOST, PORT))
    if data == 'bye':
        break
    data, addr = s.recvfrom(512)
    print('Receive from server:\n{}'.format(data.decode('utf-8')))
    data = input('输入一些信息:\n')
s.close()
