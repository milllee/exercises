#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 16_4.py
# Create Time: 2017年06月01日 星期四 01时01分12秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''自定义对象实例的持久化相关方法有:
save()                                  # 保存对象数据到数据库中
update()                                # 更新对象数据到数据库中
update_one()                            # 根据对象数据更新一个匹配的文档
delete()                                # 删除对象数据(从数据库中)
object()                                # 查询数据库中符合条件的文档

mongoengine的使用实例
'''

import random
from mongoengine import *                                       # 导入mongoengine库

connect('test')                                                 # 连接数据库test

class Stu(Document):                                            # 定义ORM框架类
    sid = SequenceField()                                       # 定义序号属性
    name = StringField()                                        # 定义字符串类型属性 
    passwd = StringField()                                      # 定义字符串类型属性 

    def introduce(self):                                        # 定义显示自己的方法
        print('序号: {}'.format(self.sid), end=' ')
        print('姓名: {}'.format(self.name), end=' ')
        print('密码: {}'.format(self.passwd))

    def set_pw(self, pw):                                       # 定义修改密码的方法
        if pw:
            self.passwd = pw
            self.save()

src = 'abcdefghijklmnopqrstuvwxyz'

def get_str(x, y):
    str_sum = random.randint(x, y)
    astr = ''
    for i in range(str_sum):
        astr += random.choice(src)
    return astr

if __name__ == '__main__':
    print('插入一个文档: ')
    stu = Stu(name='miller', passwd='123123')                   # 创建一个类(对应一个文档)
    stu.save()                                                  # 持久化类(保存文档)

    stu = Stu.objects(name='miller').first()                    # 查询出数据并初始化类
    if stu:
        stu.introduce()                                         # 显示类(文档)信息

    print('插入多个文档')
    for i in range(3):                                          # 插入3个文档
        Stu(name=get_str(2, 4), passwd=get_str(6, 8)).save()

    stus = Stu.objects()                                        # 查询所有文档
    for stu in stus:                                            # 遍历文档并逐个显示
        stu.introduce()

    print('修改一个文档')
    stu = Stu.objects(name='miller', passwd='123123').first()   # 查询某个文档(自动化构建为类)
    if stu:
        stu.name = 'aaaa'                                       # 修改实例属性
        stu.save()                                              # 持久化存入数据库
        stu.set_pw('bbbbbbb')                                   # 调用类的业务方法,修改passwd
        stu.introduce()

    print('删除一个文档')
    stu = Stu.objects(name='aaaa').first()                      # 查询获取一个文档
    stu.delete()                                                # 删除一个文档

    stus = Stu.objects()                                        # 查询所有文档
    for stu in stus:                                            # 遍历文档并逐个显示
        stu.introduce()
