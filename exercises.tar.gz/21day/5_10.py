#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 5_10.py
# Create Time: 2017年05月10日 星期三 16时38分01秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''调用函数对提供的可变和不可变参数进行修改前后的效果
'''

def change(aint, alst):
    aint = 0
    alst[0] = 0
    alst.append(4)
    print('函数中aint: {}'.format(aint))
    print('函数中alst: {}'.format(alst))

aint = 3
alst = [1, 2, 3]
print('调用前 aint: {}'.format(aint))
print('调用前 alst: {}'.format(alst))
change(aint, alst)
print('调用后 aint: {}'.format(aint))
print('调用后 alst: {}'.format(alst))
