#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 17_15.py
# Create Time: 2017年06月07日 星期三 22时47分33秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''在Tornado框架的Web编程中，也可以实现与Flask中相同的URL转向的功能。Tornado框架中有两种方法可以实现URL转向:
* redirect(url)     # 在业务逻辑中转向URL
* RedirectHandler   # 实现某个URL的直接转向
RedirectHandler 类的具体使用形式为:
(r'/aaa', tornado.web.RedirectHandler, dict(url='/abc'))

两种URL转向的实例
'''

import tornado.ioloop
import tornado.web

class DistHdl(tornado.web.RequestHandler):
    def get(self):
        self.write('被转向的目的页面！')

class SrcHdl(tornado.web.RequestHandler):
    def get(self):
        self.redirect('/dist')                                  # 在业务逻辑中转向

app = tornado.web.Application([
    (r'/dist', DistHdl),
    (r'/src', SrcHdl),
    (r'/rdrt', tornado.web.RedirectHandler, {'url': '/src'})    # 直接转向
    ])

if __name__ == '__main__':
    app.listen(8999)
    tornado.ioloop.IOLoop.instance().start()
