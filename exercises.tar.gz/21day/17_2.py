#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 17_2.py
# Create Time: 2017年06月06日 星期二 16时05分05秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''多个URL装饰器同时装饰一个函数的实例
'''

import flask                                # 导入flask

app = flask.Flask(__name__)                 # 实例化主类Flask

@app.route('/')                             # 装饰器(实现URL地址)
@app.route('/hello')
def helo():                                 # 定义业务函数
    return '你好，又是我Flask'              # 返回字符串

if __name__ == '__main__':
    app.run('0.0.0.0', 8888)                # 运行程序
