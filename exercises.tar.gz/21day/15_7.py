#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 15_7.py
# Create Time: 2017年06月01日 星期四 10时25分12秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''subprocess模块可以用于创建新的进程，并获得它的输入、输出及错误信息，提供了更高级的接口，
可以替换os.system、os.spawn*、popen等，subprocess模块基本函数如下:
call(args, *, stdin=None, stdout=None, stderr=None, shell=False, timeout=None)
    # 创建新进程运行程序，输入和输出绑定到父进程，返回新进程退出码
check_all(args, *, stdin=None, stdout=None, stderr=None, shell=False, timeout=None)
    # 创建新进程运行程序，输入和输出绑定到父进程，退出码为0正常返回，否则引发CalledProcessError
getstatusoutput(cmd)    # 创建新进程运行程序，元组形式返回新进程退出码和输出
getoutput(cmd)          # 创建新进程运行程序，返回新进程的输出(字符串)
check_output(args, *, input=None, stdin=None, stderr=None, shell=False, universal_newlines=False, timeout=None)
    # 创建新进程运行程序，返回新进程的输出(bytesarray)

* stdin、stdout、stderr         用来处理新进程的输入、输出和错误信息
* shell                         是否使用一个中间shell来执行(可以使用shell相关变量等)
* input                         为命令行提供一个输入信息(字符串)，不能与stdin同时使用
* universal_newline             返回值和输入值为字符串而不是bytes

以上各函数的使用方法及效果
'''

import subprocess

print('call() test: {}'.format(subprocess.call(['python3', 'protest.py'])))
print('')
print('check_call() test: {}'.format(subprocess.check_call(['python3', 'protest.py'])))
print('')
print('getstatusoutput() test: {}'.format(subprocess.getstatusoutput(['python3', 'protest.py'])))
print('')
print('getoutput() test: {}'.format(subprocess.getoutput(['python3', 'protest.py'])))
print('')
print('check_output() test: {}'.format(subprocess.check_output(['python3', 'protest.py'])))
