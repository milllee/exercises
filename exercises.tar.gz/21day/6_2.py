#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 6_2.py
# Create Time: 2017年05月10日 星期三 17时28分14秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''一个定义两个方法的类及其使用方法
'''

class SmplClass:                # 定义一个类
    def info(self):
        print('我定义的类')     # 定义一个类方法info()

    def mycacl(self, x, y):     # 定义一个类方法mycacl()
        return x + y

sc = SmplClass()                # 实例化类SmplClass()
print('调用info方法的结果: ')
sc.info()                       # 调用类实例sc的info()方法
print('调用mycacl方法的结果: ')
print(sc.mycacl(3, 4))
