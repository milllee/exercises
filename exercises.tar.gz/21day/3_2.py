#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 3_2.py
# Create Time: 2017年05月10日 星期三 14时20分13秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

print('int("23.5"):\t{}'.format(int(23.5)))      # 浮点数 -> 整数
print('int("23.001"):\t{}'.format(int(23.001)))  # 浮点数 -> 整数
print('int(23):\t{}'.format(int('23')))          # 字符串 -> 整数

print('float(3):\t{}'.format(float(3)))          # 整数   -> 浮点数
print('float("3"):\t{}'.format(float('3')))      # 字符串 -> 浮点数
print('float("3.2"):\t{}'.format(float('3.2')))  # 字符串 -> 浮点数

print('str(23):\t{}'.format(str(23)))            # 整数   -> 字符串
print('str(23.3):\t{}'.format(str(23.3)))        # 浮点数 -> 字符串

print('int("23.3"):\t{}'.format(int('23.3')))    # 字符串 -> 整数(报错: 浮点数组成的字符串，不能直接转换为整数)
