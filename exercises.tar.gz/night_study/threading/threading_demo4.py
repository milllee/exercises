#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: threading_demo4.py

import threading
import time

def say(langue, x):
    time.sleep(5)
    print "my func is {}, {} is mine.".format(langue, x)

class MyThread(threading.Thread):
    def __init__(self, target, *args):
        threading.Thread.__init__(self)
        self.func = target
        self.args = args

    def run(self):
        self.func(*self.args)

say1 = MyThread(say, 'python', 1)
say2 = MyThread(say, 'C', 2)
say3 = MyThread(say, 'C++', 3)
say1.start()
say2.start()
say3.start()
say1.join()
say2.join()
say3.join()
