#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# Filename: Hello.py

class Hello(object):
    def hello(self, name='world'):
        print('Hello %s' % name)

if __name__ == '__main__':
    he = Hello()
    he.hello()
