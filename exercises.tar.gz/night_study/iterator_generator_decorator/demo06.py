# -*- coding: UTF-8 -*-

# 闭包
# 函数套函数

# count = 0
# # 作用域 L -> E -> G -> B
# def add(x, y):
#     # global count
#     count = 3
#     # result = x + y
#     # return result
# print add(1, 2)
# print count

def add(x, y):
    return x + y
def sub(x, y):
    return x - y
def callback(func, x, y):
    return func(x, y)
print callback(add, 1, 1)
print callback(sub, 1, 1)
# 函数其实也是一个特殊的变量
# print add
# print sub
# add = """
# x + y
# """
