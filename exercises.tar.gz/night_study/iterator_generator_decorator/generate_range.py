#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: generate_range.py
# Create Time: 2017年03月22日 星期三 05时37分27秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def myrange(stop):
    n = 0
    while n <= stop:
        rcv = yield n
        n += 1
        

if __name__ == '__main__':
    for i in myrange(8):
        print(i),
