#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: decorate_demo3.py
# Create Time: 2017年03月22日 星期三 05时00分33秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import time

def abc(myclass):
    class InnerClass:
        def __init__(self, z=0):
            self.z = 0
            self.wrapper = myclass()
#            print self.wrapper

        def position(self):
            self.wrapper.position()
#            print self.wrapper.position()
            print('z ax is: {}'.format(self.z))
    return InnerClass

@abc
class coordination:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
#        print self.x, self.y

    def position(self):
        print('x ax is: {}'.format(self.x))
        print('y ax is: {}'.format(self.y))

if __name__ == '__main__':
    coor = coordination()
    coor.position()
