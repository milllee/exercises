# -*- coding: UTF-8 -*-

def aoo():
    yield 1
    yield 2
    yield 3
    yield 4
gen = aoo()
print gen.next()
gen.close()
print gen.next()
print gen.next()
print gen.next()
print gen.next()
