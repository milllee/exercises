#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: decorate_range.py
# Create Time: 2017年03月22日 星期三 05时28分52秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def abc(fun):
    def mabc(*args, **kwargs):
        print('开始运行。。。')
        fun(*args, **kwargs)
        print('结束运行。。。。。')
    return mabc

@abc
def myrange(n):
    for i in range(n):
        print(i)

r1 = myrange(10)
r2 = myrange(20)
