# -*- coding: UTF-8 -*-
'''range()和xrange()的区别'''

import time

start_time = time.time()
for i in range(10000000):
    pass
range_time = time.time() - start_time

start_time = time.time()
for i in xrange(10000000):
    pass
xrange_time = time.time() - start_time

print "range_time:{0}".format(range_time)
print "xrange_time:{0}".format(xrange_time)
