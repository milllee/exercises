# -*- coding: UTF-8 -*-

# 第一次切入的时候
# next() 方法 等同于 send(None)
# def aoo():
#     yield 1
# gen = aoo()
# print gen.send(None)

def boo():
    count = yield 1
    print count
gen1 = boo()
print gen1.next()
print gen1.send(100)
