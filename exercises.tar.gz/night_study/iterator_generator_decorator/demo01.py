# -*- coding: UTF-8 -*-
'''自定义函数实现for循环'''

list_1 = range(10)
for i in list_1:
    print i

def myfor(coll):
    coll = iter(list_1)
    while True:
        try:
            print coll.next()
        except StopIteration:
            break

myfor(list_1)
