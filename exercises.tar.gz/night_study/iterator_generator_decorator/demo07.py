# -*- coding: UTF-8 -*-

import time

# 写一个函数，该函数的作用就是计算传入函数的执行时间
def run_time(func):
    def inner(*args, **kwargs):
        start_time = time.time()
        func(*args, **kwargs)
        print "method run time: {0}".format(time.time() - start_time)
    return inner

@run_time  # aoo = run_time(aoo)
def aoo(x):
    time.sleep(2)
    return x

@run_time
def boo(x, y):
    time.sleep(3)
    return x + y

print aoo(19)
print boo(y=18, x=2)
