#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: generate_demo1.py
# Create Time: 2017年03月22日 星期三 04时02分39秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def myYield(n):
    while n > 0:
        rcv = yield n
        n -= 1
        if rcv is not None:
            n = rcv

if __name__ == '__main__':
    my_yield = myYield(3)
    print(my_yield.next())
    print(my_yield.next())
    print('传给生成器一个值，重新初始化生成器。')
    print(my_yield.send(10))
    print(my_yield.next())
