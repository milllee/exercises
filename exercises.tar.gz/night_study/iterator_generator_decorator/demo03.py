# -*- coding: UTF-8 -*-

# 生成器
# 1.生成器表达式
# 2.生成器函数

# 生成器表达式
# 只需要将列表生成式两边的[]换成()那么就变成了生成器表达式
# gen = ( i for i in range(10) )
# print gen.next()

# 生成器函数
# 只要一个函数中，出现了一次或者多次 yield 关键字，那么我们就把这个函数叫做生成器函数
# 每次碰到 yield 就会返回一次值
def aoo():
    yield 1
    yield 2
    yield 3
# gen = aoo()
# print gen.next()
# print gen.next()
# print gen.next()

def add():
    i = 0
    while True:
        print "yield 1"
        yield i
        print "yield 2"
        i += 1

gen = add()
print gen.next()
print gen.next()
