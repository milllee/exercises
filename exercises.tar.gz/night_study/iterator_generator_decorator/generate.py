#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: generate.py
# Create Time: 2017年03月22日 星期三 02时53分41秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def myYield(n):
    while n > 0:
        print '开始生成。。。:'
        yield n
        print n
        print '完成一次。。。:'
        n -= 1

if __name__ == '__main__':
    for i in myYield(4):
        print '遍历得到的值: {}'.format(i)
    print ''
    my_yield = myYield(3)
    print '已经实例化生成器对象'
    my_yield.next()
    print '第二次调用next()方法: '
    my_yield.next()
    print '第三次调用next()方法: '
    my_yield.next()
    print '第四次调用next()方法: '
#    my_yield.next()
