#!/usr/bin/env python
# -*- conding: UTF-8 -*-
# Filename: prime.py

x = (int(input('the first interger:')), int(input('the second interger:')))
x1 = min(x)
x2 = max(x)
for i in range(x1, x2+1):
    for j in range(2, i):
        if i % j == 0:
            break
    else:
        print '%d is a sushu.' % i
