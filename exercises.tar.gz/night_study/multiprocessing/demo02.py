# -*- coding: UTF-8 -*-

import time
import multiprocessing

def add():
    count = 0
    for i in xrange(1000000):
        count += i

if __name__ == "__main__":
    start_time = time.time()
    processing_list = []
    for _ in xrange(100):
        t = multiprocessing.Process(target=add)
        t.start()
        processing_list.append(t)
    [ t.join() for t in processing_list ]
    print "threading run time:{}s".format(time.time() - start_time)