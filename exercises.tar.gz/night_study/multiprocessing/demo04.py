# -*- coding: UTF-8 -*-

import os
import multiprocessing

# 第二种创建进程的方式，继承。

class Process(multiprocessing.Process):

    def __init__(self):
        super(Process, self).__init__()
    
    def run(self):
        print "PID: {}".format(os.getpid())

def do_something():
    print "PID: {}".format(os.getpid())

if __name__ == "__main__":
    # 创建进程
    p1 = Process()
    p1.start()
    # Thread-N N 是一个十进制的整数
    # Process-N N 是一个十进制的整数
    print p1.name
    print p1.is_alive()
    print multiprocessing.active_children()
    print multiprocessing.current_process()
    p1.join()
    print p1.is_alive()
    print p1.pid # 多进程 pid 是等同于 ps -ef 看到的pid
                  # 多线程 ident 就是一个启动的标示，没有任何意义。 ps -T -p $PID
    print p1.exitcode # 进程 exitcode 等同于 echo $?
    p1.terminate() # 进程 terminate 等同于 kill -15
    print multiprocessing.active_children()
    print multiprocessing.current_process()
    print multiprocessing.cpu_count()