# -*- coding: UTF-8 -*-

import time
import multiprocessing


def add(count, lock):
    with lock:
        new = count["add"] + 1
        time.sleep(0.01)
        count["add"] = new
        print "add method : {}".format(count)

if __name__ == "__main__":
    # lock = threading.Lock()
    lock = multiprocessing.Lock()
    manager = multiprocessing.Manager()
    d = manager.dict()
    d["add"] = 0
    processing_list = []
    for _ in xrange(10):
        p1 = multiprocessing.Process(target=add, args=(d,lock))
        p1.start()
        processing_list.append(p1)
    [ p.join() for p in processing_list]
    print "main method : {}".format(d)
