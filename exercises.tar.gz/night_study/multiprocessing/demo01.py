# -*- coding: UTF-8 -*-

import time
import threading

def add():
    count = 0
    for i in xrange(1000000):
        count += i

if __name__ == "__main__":
    start_time = time.time()
    threading_list = []
    for _ in xrange(100):
        t = threading.Thread(target=add)
        t.start()
        threading_list.append(t)
    [ t.join() for t in threading_list ]
    print "threading run time:{}s".format(time.time() - start_time)