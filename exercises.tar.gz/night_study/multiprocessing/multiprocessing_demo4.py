#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_demo4.py
# Create Time: 2017年04月08日 星期六 18时16分19秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import multiprocessing as mp
import time

def say(n):
    time.sleep(2)
    return 'say {}'.format(n) # 此处原来为print,改为return没有输出值了。

p = mp.Pool(2)
all_mp = []
for i in range(1, 6):
    all_mp.append(p.apply_async(say, args=(i,)))
p.close()
p.join()
for result in all_mp:
    print result.get()
# 此程序为school_demo3.py的简写版本
