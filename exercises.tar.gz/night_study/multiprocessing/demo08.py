# -*- coding: UTF-8 -*-

import multiprocessing


def test_function(l, d):
    l.append(100)
    d["key"] = "Value"

if __name__ == "__main__":
    manager = multiprocessing.Manager()
    # 共享列表
    l = manager.list()
    # 共享字典
    d = manager.dict()
    p = multiprocessing.Process(target=test_function, args=(l, d))
    p.start()
    p.join()
    print l
    print d
   