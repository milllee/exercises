# -*- coding: UTF-8 -*-

import time 
import threading
import multiprocessing


def test_function():
    pass


if __name__ == "__main__":
    # 创建 100 个线程
    start_time = time.time()
    for _ in xrange(100):
        t = threading.Thread(target=test_function)
        t.start()
        t.join()
    print "threading time: {}".format(time.time() - start_time)
    
    start_time = time.time()
    # 创建 100 个进程
    for _ in xrange(100):
        p = multiprocessing.Process(target=test_function)
        p.start()
        p.join()
    print "multiprocessing time: {}".format(time.time() - start_time)