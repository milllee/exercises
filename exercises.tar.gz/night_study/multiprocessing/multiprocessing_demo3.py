#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_demo3.py
# Create Time: 2017年04月08日 星期六 18时16分19秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import multiprocessing as mp
import time

def say(n):
    time.sleep(2)
    return 'say {}'.format(n) # 此处原来为print,改为return没有输出值了。

p = mp.Pool(2)
m1 = p.apply_async(say, args=(1,))
m2 = p.apply_async(say, args=(2,))
m3 = p.apply_async(say, args=(3,))
m4 = p.apply_async(say, args=(4,))
#print m1.get() # 放在此处可能会阻塞，是误区
#print m2.get()
#print m3.get()
#print m4.get()
p.close()
p.join()
print 'ending'
print m1.get() # 进程池的get()方法可获取进程返回值，
print m2.get() # 必须放在join()方法之后，放在之前
print m3.get() # 是误区，可能会阻塞住
print m4.get()
