# -*- coding: UTF-8 -*-

import time
import multiprocessing

class ProcessPool(object):

    def __init__(self, queue_limit=None):
        if queue_limit is None:
            self.__queue = multiprocessing.JoinableQueue(multiprocessing.cpu_count())
            for _ in xrange(multiprocessing.cpu_count()):
                Process(self.__queue)
        else:
            self.__queue = multiprocessing.JoinableQueue(queue_limit)
            for _ in xrange(queue_limit):
                Process(self.__queue)
        
    def apply_async(self, func=None, args=(), kwargs={}):
        self.__queue.put((func, args, kwargs))
        
    def join(self):
        self.__queue.join()
        
class Process(multiprocessing.Process):

    def __init__(self, queue):
        super(Process, self).__init__()
        self.__queue = queue
        self.daemon = True
        self.start()
    
    def run(self):
        while True:
            func, args, kwargs = self.__queue.get()
            func(*args, **kwargs)
            self.__queue.task_done()

def run(task_id):
    print "{} run ~".format(task_id)
    time.sleep(1)

if __name__ == "__main__":
    pool = ProcessPool()
    for number in xrange(10):
        # p = multiprocessing.Process(target=run, args=(number,))
        # p.start()
        pool.apply_async(func=run, args=(number,))
    pool.join()