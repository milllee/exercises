# -*- coding: UTF-8 -*-

import os
import multiprocessing

# 第一种创建进程的方式，直接创建。

def do_something():
    print "PID: {}".format(os.getpid())

if __name__ == "__main__":
    # 创建线程
    # threading.Thread(target=do_something, args=(), kwargs={})
    
    # 创建进程
    p1 = multiprocessing.Process(target=do_something)
    p1.start()