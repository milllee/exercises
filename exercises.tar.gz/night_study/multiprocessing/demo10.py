# -*- coding: UTF-8 -*-

import time
import multiprocessing


def run(task_id):
    print "{} run ~".format(task_id)
    time.sleep(1)

if __name__ == "__main__":
    pool = multiprocessing.Pool(3)
    for number in xrange(10):
        # p = multiprocessing.Process(target=run, args=(number,))
        # p.start()
        pool.apply_async(func=run, args=(number,))
    pool.close()
    pool.join()