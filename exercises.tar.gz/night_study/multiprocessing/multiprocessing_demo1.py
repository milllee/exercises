#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_demo1.py
# Create Time: 2017年04月08日 星期六 17时52分49秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import multiprocessing as mp
import time

def say(n):
    time.sleep(2)
    print 'say {}'.format(n)

p = mp.Pool(2)
p.apply(say, args=(1,))
p.apply(say, args=(2,))
p.apply(say, args=(3,))
p.apply(say, args=(4,))
p.apply(say, args=(5,))
p.close()
p.join()
