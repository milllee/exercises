# -*- coding: UTF-8 -*-

import time
import multiprocessing


def test_function(conn2):
    # print conn2.recv()
    conn2.send("hello2")

if __name__ == "__main__":
    # Pipe 参数为 True （默认的）
    # conn1 conn2 都可以互相发送和接受数据
    # Pipe 参数为 False
    # conn1 只能用来接受
    # conn2 只能用法发送
    conn1, conn2 = multiprocessing.Pipe(False)
    p = multiprocessing.Process(target=test_function, args=(conn2,))
    p.start()
    # conn1.send("hello ")
    print conn1.recv()
   