# -*- coding: UTF-8 -*-

import time
import multiprocessing


def test_function(task_id, bs):
    with bs:
        print "{} run~".format(task_id)
        time.sleep(1)

if __name__ == "__main__":
    bs = multiprocessing.BoundedSemaphore(3)
    processing_list = []
    for number in xrange(10):
        p = multiprocessing.Process(target=test_function, args=(number, bs))
        p.start()
        processing_list.append(p)
    [ p.join() for p in processing_list ]