#!/usr/bin/env python
# -*- conding: UTF-8 -*-
# Filename: while.py

list1 = [1, 2, 3, 4, 5]
total = len(list1)
i = 0
while i < total:
    print "%d's ping fang is: %d" % (i, list1[i] * list1[i])
    i += 1
else:
    print('it is over')
