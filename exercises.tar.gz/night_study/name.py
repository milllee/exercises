#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: name.py

name = ''
while not name or name.isspace(): 
    name = raw_input("what's your name? ")
print 'Hello, %s'% name
