#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: asyncio_demo2.py
# Create Time: 2017年04月08日 星期六 09时06分32秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import threading
import asyncio

#@asyncio.coroutine
async def hello():
    print('Hello world! ({})'.format(threading.currentThread()))
#    yield from asyncio.sleep(1)
    await asyncio.sleep(1)
    print('Hello again! ({})'.format(threading.currentThread()))

loop = asyncio.get_event_loop()
tasks = [hello(), hello()]
loop.run_until_complete(asyncio.wait(tasks))
loop.close()
