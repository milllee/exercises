#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: asyncio_demo3.py
# Create Time: 2017年04月08日 星期六 09时13分44秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import asyncio

#@asyncio.coroutine
async def wget(host):
    print('wget {}...'.format(host))
    connect = asyncio.open_connection(host, 80)
#    reader, writer = yield from connect
    reader, writer = await connect
    header = 'GET / HTTP/1.0\r\nHost: {}\r\n\r\n'.format(host)
    writer.write(header.encode('utf-8'))
#    yield from writer.drain()
    await writer.drain()
    while True:
#        line = yield from reader.readline()
        line = await reader.readline()
        if line == b'\r\n':
            break
        print('{} header > {}'.format(host, line.decode('utf-8').rstrip()))
    writer.close()

loop = asyncio.get_event_loop()
tasks = [wget(host) for host in ['www.sina.com.cn', 'www.sohu.com', 'www.163.com', 'www.meitulu.com']]
loop.run_until_complete(asyncio.wait(tasks))
loop.close()
