#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: urllib_demo2.py
# Create Time: 2017年04月07日 星期五 19时49分31秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

from urllib import request

req = request.Request('http://www.douban.com')
req.add_header('User-Agent', 'Mozilla/6.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Geoko) Version/8.0 Mobile/10A5376e Safari/8536.25')
with request.urlopen(req) as f:
    print('Status: {} {}'.format(f.status, f.reason))
    for k, v in f.getheaders():
        print('{}: {}'.format(k, v))
    print('Data: {}'.format(f.read().decode('utf-8')))
