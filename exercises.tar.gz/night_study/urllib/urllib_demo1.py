#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: urllib_demo1.py
# Create Time: 2017年04月07日 星期五 19时42分06秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

from urllib import request

with request.urlopen('https://api.douban.com/v2/book/2129650') as f:
    data = f.read()
    print('Status: {} {}'.format(f.status, f.reason))
    for k, v in f.getheaders():
        print('{}: {}'.format(k, v))
    print('Data: {}'.format(data.decode('utf-8')))
