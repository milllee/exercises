#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: queue_demo2.py

import Queue

def work(i, q):
    while True:
        langue = q.get()
        print "work->撸代码:", langue
        time.sleep(2)
        print "work-> %s, end" % langue
        q.task_done()

if __name__ == '__maiin__':
    q = Queue.Queue()
