# -*- coding: UTF-8 -*-

import time
import gevent

def run1():
    print "run1 start"
    time.sleep(2)
    print "run1 end"

def run2():
    print "run2 start"
    time.sleep(1)
    print "run2 end"

def run3():
    print "run3 start"
    time.sleep(0)
    print "run3 end"

if __name__ == "__main__":
    start_time = time.time()
    g1 = gevent.spawn(run1)
    g2 = gevent.spawn(run2)
    g3 = gevent.spawn(run3)
    g1.join()
    g2.join()
    g3.join()
    print "run time: {}".format(time.time() - start_time)
