# -*- coding: UTF-8 -*-

import time
import gevent

def run1():
    print "run1 start"
    time.sleep(2)
    print "run1 end"

def run2():
    print "run2 start"
    time.sleep(1)
    print "run2 end"

def run3():
    print "run3 start"
    time.sleep(0)
    print "run3 end"

if __name__ == "__main__":
    start_time = time.time()
    run1()
    run2()
    run3()
    print "run time: {}".format(time.time() - start_time)
