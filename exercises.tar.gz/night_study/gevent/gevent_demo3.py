#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: gevent_demo3.py
# Create Time: 2017年04月07日 星期五 20时41分36秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

from gevent import monkey; monkey.patch_all()
import gevent
import urllib2

def f(url):
    print('GET: {}'.format(url))
    resp = urllib2.urlopen(url)
    data = resp.read()
    print('{} bytes received from {}.'.format(len(data), url))

gevent.joinall([
    gevent.spawn(f, 'http://www.python.org/'),
    gevent.spawn(f, 'http://www.yahoo.com/'),
    gevent.spawn(f, 'http://github.com/')
])
