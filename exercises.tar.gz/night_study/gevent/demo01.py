# -*- coding: UTF-8 -*-

import gevent
import threading

def run(task_id):
    print "{} run method ~".format(task_id)

if __name__ == "__main__":
    # t = threading.Thread(target=run, kwargs={"task_id":1})
    # t.start()
    # 传入位置参数
    # g = gevent.spawn(run, 1)
    # 传入关键字参数
    g = gevent.spawn(run, task_id=1)
    # t.join()
    g.join()
    
