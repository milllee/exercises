# -*- coding: UTF-8 -*-

import time
import urllib2

def download(url, filename):
    with open(filename, 'w+') as file_obj:
        f = urllib2.urlopen(url) 
        data = f.read() 
        file_obj.write(data)

if __name__ == "__main__":
    start_time = time.time()
    download("http://www.youku.com", "youku")
    download("http://www.iqiyi.com", "iqiyi")
    download("http://www.tudou.com", "tudou")
    print "run time:{}".format(time.time() - start_time)
