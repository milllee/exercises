#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: gevent_demo4.py
# Create Time: 2017年04月07日 星期五 21时04分35秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def consumer():
    r = ''
    while True:
        n = yield r # 3 consumer通过yield拿到消息，处理之后通过yield把结果传回
        if not n:
            return
        print('[CONSUMER] Consuming {}...'.format(n))
        r = '200 OK'

def produce(c):
    c.send(None) # 1 启动生成器
    n = 0
    while n <= 5:
        n += 1
        print('[PRODUCER] Producing {}...'.format(n))
        r = c.send(n) # 2 通过c.send(n)切换到consumer执行
        print('[PRODUCER] Consumer return: {}'.format(r)) # 4 produce拿到consumer处理的结果，继续产生下一条消息
    c.close() # 5 produce决定不产生消息，通过c.close()关闭consumer

c = consumer()
produce(c)
