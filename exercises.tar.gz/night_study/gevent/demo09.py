# -*- coding: UTF-8 -*-

import gevent
from gevent import local

def run1():
    global count
    count.x = 1
    print "at run1 method: {}".format(count.x)

def run2():
    global count
    count.x = 2
    print "at run2 method: {}".format(count.x)

if __name__ == "__main__":
    count = local.local()
    count.x = 0
    gevent.joinall([
        gevent.spawn(run1),
        gevent.spawn(run2)
    ])
    print count.x
