# -*- coding: UTF-8 -*-

import time
import gevent
import threading

def run1():
    print "run1 start"
    time.sleep(2)
    print "run1 end"

def run2():
    print "run2 start"
    time.sleep(1)
    print "run2 end"

def run3():
    print "run3 start"
    time.sleep(0)
    print "run3 end"

if __name__ == "__main__":
    start_time = time.time()
    t1 = threading.Thread(target=run1)
    t2 = threading.Thread(target=run2)
    t3 = threading.Thread(target=run3)
    t1.start()
    t2.start()
    t3.start()
    t1.join()
    t2.join()
    t3.join()
    print "run time: {}".format(time.time() - start_time)
