# -*- coding: UTF-8 -*-

from gevent import monkey
monkey.patch_socket()
import time
import urllib2
import gevent

def download(url, filename):
    with open(filename, 'w+') as file_obj:
        f = urllib2.urlopen(url) 
        data = f.read() 
        file_obj.write(data)

if __name__ == "__main__":
    start_time = time.time()
    gevent.joinall([
        gevent.spawn(download, "http://www.youku.com", "youku"),
        gevent.spawn(download, "http://www.iqiyi.com", "iqiyi"),
        gevent.spawn(download, "http://www.tudou.com", "tudou")
    ])
    print "run time:{}".format(time.time() - start_time)
