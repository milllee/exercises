# -*- coding: UTF-8 -*-

import gevent
from gevent import queue

def run1():
    queue.put("hello run 2")

def run2():
    print queue.get()

if __name__ == "__main__":
    queue = queue.Queue()
    gevent.joinall([
        gevent.spawn(run1),
        gevent.spawn(run2)
    ])
