#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_3.2.py
# Create Time: 2017年04月24日 星期一 17时19分00秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

import math
for i in range(10000):
    x=(math.sqrt(i+100))%1
    y=(math.sqrt(i+268))%1
    if x==0 and y==0:
        print(i)
