#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_24.py
# Create Time: 2017年05月02日 星期二 16时42分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：有一分数序列：2/1，3/2，5/3，8/5，13/8，21/13...求出这个数列的前20项之和。

程序分析：请抓住分子与分母的变化规律,(斐波那契数列)
'''

count = 0
a, b = 1, 2
for i in range(1, 21):
    count += b / a
    a, b = b, a + b
print(count)
