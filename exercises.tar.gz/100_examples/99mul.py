#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 99mul.py
# Create Time: 2017年04月16日 星期日 07时04分05秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

for i in range(1, 10):
    for j in range(1, i+1):
        print('{} x {} = {:2d} '.format(j, i, i * j), end=' ')
    print('')
