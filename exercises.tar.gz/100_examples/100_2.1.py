#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_2.1.py
# Create Time: 2017年04月24日 星期一 16时09分28秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

i = int(input('净利润:'))
arr = [1000000, 600000, 400000, 200000, 100000, 0]
rat = [0.01, 0.015, 0.03, 0.05, 0.075, 0.1]
r = 0
for idx in range(6):
    if i > arr[idx]:
        r += (i - arr[idx]) * rat[idx]
        print((i - arr[idx]) * rat[idx])
        i = arr[idx]

print(r)
