#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_8.2.py
# Create Time: 2017年04月25日 星期二 18时11分44秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''python-3.6使用for循环
'''

for i in range(1, 10):
    for j in range(1, 10):
        print('{} x {} = {}'.format(j, i, i*j), end=' ')
        if i == j:
            print()
            break
