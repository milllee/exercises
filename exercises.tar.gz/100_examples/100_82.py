#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_82.py
# Create Time: 2017年05月09日 星期二 10时19分10秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：八进制转换为十进制
'''

if __name__ == '__main__':
    n = 0
    p = input('输入一个八进制数: ')
#    a = '0o' + p
#    x = int(a, 8)
#    print(x)
    for i in range(len(p)):
        n = n * 8 + ord(p[i]) - ord('0') # 输入10:i = 0时,p[0]等于1,n=1;i=1时,n = 8 + p[i]
    print(n)
