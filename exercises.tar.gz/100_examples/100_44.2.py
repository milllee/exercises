#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_44.2.py
# Create Time: 2017年05月04日 星期四 14时32分43秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

x = [[12, 7, 3],
    [4, 5, 6],
    [7, 8, 9]]

y = [[5, 8, 1],
    [6, 7, 3],
    [4, 5, 9]]

c = []
d = []

for index, element in enumerate(x):
    for i in range(len(element)):
        m = x[index][i] + y[index][i]
        c.append(m)

        if len(c) == len(element):
            d.append(c)
            c = []

print(d)
