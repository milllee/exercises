#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_5.3.py
# Create Time: 2017年04月25日 星期二 14时40分51秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

x = int(input('第1个数:'))
y = int(input('第2个数:'))

Max = max(x, y)
Min = min(x, y)

z = int(input('第3个数:'))
if z > Max:
    print(Min, Max, z)
elif z < Min:
    print(z, Min, Max)
else:
    print(Min, z, Max)
