#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_97.py
# Create Time: 2017年05月09日 星期二 20时43分55秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：从键盘输入一些字符，逐个把它们送到磁盘上去，直到输入一个#为止
'''

from sys import stdout

if __name__ == '__main__':
    filename = input('输入一个要保存到的文件: ')
    with open(filename, 'w+') as f:
        ch = input('输入字符串: ')
        while ch != '#':
            f.write(ch)
            stdout.write(ch)
            ch = input('')
