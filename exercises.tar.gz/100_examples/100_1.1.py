#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_1.1.py
# Create Time: 2017年04月24日 星期一 15时05分11秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

d = []
for i in range(1, 5):
    for j in range(1, 5):
        for k in range(1, 5):
            if (i != j) and (i != k) and (j != k):
                d.append(i * 100 + j * 10 + k)
print('1-4组成3位无重复数字的数量是: {}'.format(len(d)))
print('它们分别是: {}'.format(d))
