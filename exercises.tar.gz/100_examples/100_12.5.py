#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_12.5.py
# Create Time: 2017年04月26日 星期三 15时59分23秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def isPrime(n): 
    if n <= 1: 
        return False
    if n == 2: 
        return True
    if n % 2 == 0: 
        return False
    i = 3
    while i * i <= n: 
        if n % i == 0: 
            return False
        i += 2
    return True

for i in range(1, 101):
    if isPrime(i) == True:
        print(i)
