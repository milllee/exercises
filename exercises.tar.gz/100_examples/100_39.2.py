#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_39.2.py
# Create Time: 2017年05月03日 星期三 18时15分59秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

if __name__ == '__main__':
    # 方法一 ： 0 作为加入数字的占位符
    a = [1,4,6,9,13,16,19,28,40,100,0]
    print('原始列表:')
    for i in range(len(a)):
        print(a[i], end=' ')
    number = int(input("\n插入一个数字:"))
    end = a[9]
    if number > end:
        a[10] = number
    else:
        for i in range(10):     # 判断此数是否大于最后一个数，考虑插入中间的数的情况
            if a[i] > number:
                temp1 = a[i]
                a[i] = number
                for j in range(i + 1,11):   # 插入后此元素之后的数，依次后移一个位置
                    temp2 = a[j]
                    a[j] = temp1
                    temp1 = temp2
                break
    print('排序后列表:')
    for i in range(11):
        print(a[i], end=' ')
