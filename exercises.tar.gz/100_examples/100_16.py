#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_16.py
# Create Time: 2017年04月28日 星期五 10时14分58秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：输出指定格式的日期。

程序分析：使用 datetime 模块
'''

import datetime

if __name__ == '__main__':
    print(datetime.date.today().strftime('%Y-%m-%d'))

    myBirthDate = datetime.date(1986, 7, 19)
    print(myBirthDate.strftime('%d-%m-%y'))

    myBirthNextDate = myBirthDate + datetime.timedelta(days=1)
    print(myBirthNextDate.strftime('%m-%d-%Y'))

    myBirthPreviousDate = myBirthDate + datetime.timedelta(days=-1)
    print(myBirthPreviousDate)

    myFirstBirthDay = myBirthDate.replace(year=myBirthDate.year + 1)
    print(myFirstBirthDay.strftime('%m/%d/%Y'))
