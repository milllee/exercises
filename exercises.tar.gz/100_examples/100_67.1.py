#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_67.1.py
# Create Time: 2017年05月05日 星期五 15时18分22秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

a = [3, 2, 1, 8, 9, 7]
for i in range(len(a)):
    if a[i] == max(a):
        a[0], a[i] = a[i], a[0]

for i in range(len(a)):
    if a[i] == min(a):
        a[-1], a[i] = a[i], a[-1]

print(a)
