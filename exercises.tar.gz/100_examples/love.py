#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: love.py
# Create Time: 2017年05月1日 星期二 11时22分00秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

# print('\n'.join([''.join([('Love'[(x-y) % len('Love')] if ((x*0.05)**2+(y*0.1)**2-1)**3-(x*0.05)**2*(y*0.1)**3 <= 0 else ' ') for x in range(-30, 30)]) for y in range(30, -30, -1)]))

# for y in range(30, -30, -1):
#     for x in range(-30, 30):
#         if ((x * 0.05) ** 2 + (y * 0.1) ** 2 - 1) ** 3 <= (x * 0.05) ** 2 * (y * 0.1) ** 3:
# #            print('*', end='')
#             print('Love'[(x-y) % len('Love')], end='') # "%"是取余
#         else:
#             print(' ', end='')
#     print()

def Heart(Str):
    for y in range(30, -30, -1):
        for x in range(-30, 30):
            if ((x * 0.05) ** 2 + (y * 0.1) ** 2 - 1) ** 3 <= (x * 0.05) ** 2 * (y * 0.1) ** 3:
                print(Str[(x-y) % len(Str)], end='')
            else:
                print(' ', end='')
        print()

Heart('Love')
Heart('❤❤❤❤')
Heart('♡♡♡♡')
Heart('❦❦❦❦')
Heart('ღღღღ')
Heart('★★★★')
