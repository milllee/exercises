#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_29.2.py
# Create Time: 2017年05月03日 星期三 13时51分02秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

x = int(input('一个数:'))
a = x // 10000
b = x % 10000 // 1000
c = x % 1000 // 100
d = x % 100 // 10
e = x % 10

if a != 0:
    print('5位数:', e, d, c, b, a)
elif b != 0:
    print('4位数:', e, d, c, b)
elif c != 0:
    print('3位数:', e, d, c)
elif d != 0:
    print('2位数:', e, d)
else:
    print('1位数:', e)
