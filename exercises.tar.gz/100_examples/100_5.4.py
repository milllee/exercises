#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_5.4.py
# Create Time: 2017年04月25日 星期二 14时43分38秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''冒泡排序方法'''

def Sort(list):
    n = len(list)
    for i in range(1, n):
        # 一次次将最大的数打印出来
        for j in range(1, n-i+1):
            if list[j-1] > list[j]:
                list[j-1], list[j] = list[j], list[j-1]
            # 打印排序过程
            print(list)
    for i in range(n):
        print(list[i])
# 读入数据
def inputData():
    list_first = []
    while True:
        a = input('输入数字:'.strip())
        if len(a) == 0:
            return list_first
        else:
            list_first.append(a.strip())

if __name__ == '__main__':
    lt = inputData()
    print(lt)
    Sort(lt)
