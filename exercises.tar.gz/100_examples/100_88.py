#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_88.py
# Create Time: 2017年05月09日 星期二 16时36分54秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：读取7个数（1-50）的整数值，每读取一个值，程序打印出该值个数的＊
'''

if __name__ == '__main__':
    n = 1
    while n <= 7:   # 执行7次
        a = int(input('输入一个数字: '))
        while a < 1 or a > 50:  # 如果不在1-50，进入另一个while循环，直到符合再继续
            a = int(input('input a number: '))
        print(a * '*')
        n += 1  # while循环一定要设置循环结束条件
