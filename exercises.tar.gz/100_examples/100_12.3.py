#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_12.3.py
# Create Time: 2017年04月26日 星期三 13时20分34秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

from math import sqrt 
#print([ p for p in  range(2, 100) if 0 not in [ p% d for d in range(2, int(sqrt(p))+1) ] ] )
for i in range(10000, 20001):
    for j in range(2, int(sqrt(i)) + 1):
        if i % j == 0:
            break
    else:
        print(i)
