#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_89.py
# Create Time: 2017年05月09日 星期二 17时45分35秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：某个公司采用公用电话传递数据，数据是四位的整数，在传递过程中是加密的，加密规则如下：
每位数字都加上5,然后用除以10的余数代替该数字，再将第一位和第四位交换，第二位和第三位交换
'''

if __name__ == '__main__':
    a = input('输入一个四位数: ')   # a = '1234'
    aa = []
    for i in range(4):
        aa.append(int(a[i]))    # aa = [1, 2, 3, 4]
        aa[i] += 5              # aa = [6, 7, 8, 9]
        aa[i] %= 10             # aa = [6, 7, 8, 9]
    for i in range(2):
        aa[i], aa[3 - i] = aa[3 - i], aa[i] # aa = [9, 8, 7, 6]
    for i in range(4):
        print(aa[i], end='')    # aa = [9, 8, 7, 6]
