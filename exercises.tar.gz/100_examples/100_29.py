#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_29.py
# Create Time: 2017年05月03日 星期三 11时20分02秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：给一个不多于5位的正整数，要求：一、求它是几位数，二、逆序打印出各位数字。

程序分析：学会分解出每一位数
'''

num = input('输入一个最多5位的数字:')
print('该数为{}位数'.format(len(num)))
# num.reverse() # 此方法需要将输入变成列表,麻烦
num = num[::-1]   # 此方法和reverse()方法效果一样，推荐切片

print('该数反过来是:', end='')
for i in range(len(num)):
    print(num[i], end='')
# for i in range(len(num)-1, -1, -1):   #除了先将字符串反转方法外，可用range()的倒叙循环打印
#     print(num[i], end='')
