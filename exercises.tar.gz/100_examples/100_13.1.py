#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_13.1.py
# Create Time: 2017年04月27日 星期四 15时12分56秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

for x in range(1, 10):
    for y in range(10):
        for z in range(10):
            sum = x * 100 + y * 10 + z
            if x ** 3 + y ** 3 + z ** 3 == sum:
                print(sum)
