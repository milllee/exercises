#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_39.1.py
# Create Time: 2017年05月03日 星期三 17时41分24秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

L = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21]
print('原: {}'.format(L))
num = int(input('数:'))

# L.append(num)
# L.sort()
for i in range(len(L)):
   if L[i] <= num < L[i+1]:
       L.insert(i+1, num)
       break

print('新: {}'.format(L))
