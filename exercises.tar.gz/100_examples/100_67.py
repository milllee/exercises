#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_67.py
# Create Time: 2017年05月05日 星期五 14时54分30秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：输入数组，最大的与第一个元素交换，最小的与最后一个元素交换，输出数组
'''

def inp(numbers):
    for i in range(6):
        numbers.append(int(input('输入一个数字: ')))
p = 0

def arr_max(array):     # 定义获取最大值的函数
    max = 0             # 初始化max变量
    for i in range(1, len(array) - 1):
        p = i           # 把循环变量赋给p变量
        if array[p] > array[max]:   # 如果p位置的参数大于最大值，
            max = p     # 就用max替换掉p上的值
    k = max             # 找到最大的以后再赋给k
    array[0], array[k] = array[k], array[0] # 把k和0上的值调换位置...

def arr_min(array):
    min = 0
    for i in range(1, len(array) - 1):
#        p = i                              # 没必要引入那么多变量！！！
#        if array[p] < array[min]:
#            min = p
#    l = min
#    array[-1], array[l] = array[l], array[-1]
        if array[i] < array[min]:
            min = i
    array[-1], array[min] = array[min], array[-1]

def outp(numbers):
    for i in range(len(numbers)):
        print(numbers[i])

if __name__ == '__main__':
    array = []
    inp(array)
    arr_max(array)
    arr_min(array)
    print('计算结果: ')
    outp(array)
