#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_79.py
# Create Time: 2017年05月08日 星期一 17时50分04秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：字符串排序
'''

if __name__ == '__main__':
    str1 = input('输入字符串: ')
    str2 = input('输入字符串: ')
    str3 = input('输入字符串: ')
    print(str1, str2, str3)
    if str1 > str2:
        str1, str2 = str2, str1
    if str1 > str3:
        str1, str3 = str3, str1
    if str2 > str3:
        str2, str3 = str3, str2
    print(str1, str2, str3)
