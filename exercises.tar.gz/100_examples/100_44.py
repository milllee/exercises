#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_44.py
# Create Time: 2017年05月04日 星期四 14时01分45秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''两个 3 行 3 列的矩阵，实现其对应位置的数据相加，并返回一个新矩阵：

程序分析：创建一个新的 3 行 3 列的矩阵，使用 for 迭代并取出 X 和 Y 矩阵中对应位置的值，相加后放到新矩阵的对应位置中
'''
x = [[12, 7, 3, 1],
    [4, 5, 6],
    [7, 8, 9]]

y = [[5, 8, 1, 5],
    [6, 7, 3],
    [4, 5, 9]]

z = [[0, 0, 0, 0],
    [0, 0, 0],
    [0, 0, 0]]
for i in range(len(x)):
    for j in range(len(x[i])):
        z[i][j] = x[i][j] + y[i][j]
for i in range(len(x)):
    print(z[i])
