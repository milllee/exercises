#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_1.2.py
# Create Time: 2017年04月24日 星期一 15时12分22秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

list1 = [1, 2, 3, 4]

l1 = [ x * 100 +  y * 10 +  z * 1 for x in list1 for y in list1 for z in list1 if (x != y) and (x != z) and (y != z) ] 
print('数量: {}'.format(len(l1)))
print('具体为: {}'.format(l1))
