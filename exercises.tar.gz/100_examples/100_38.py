#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_38.py
# Create Time: 2017年05月03日 星期三 17时09分42秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：求一个3*3矩阵对角线元素之和。

程序分析：利用双重for循环控制输入二维数组，再将a[i][i]累加后输出
'''

a = []
sum = 0
for i in range(3):
    a.append([])
    for j in range(3):
        a[i].append(int(input('输入数字:')))

for i in range(3):
    sum += a[i][i]

print(sum)
