#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_6.2.py
# Create Time: 2017年04月25日 星期二 16时26分01秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''如果你需要输出指定个数的斐波那契数列，可以使用以下代码
'''

def Fib(n):
    if n == 1:
        return [1]
    elif n == 2:
        return [1, 1]
    fibs = [1, 1]
    for i in range(2, n):
        fibs.append(fibs[-1] + fibs[-2])
    return fibs

print(Fib(10))
