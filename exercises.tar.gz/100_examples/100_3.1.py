#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_3.1.py
# Create Time: 2017年04月24日 星期一 16时32分21秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

import math

for i in range(10001):
    if (math.sqrt(i + 100) == math.ceil(math.sqrt(i + 100))) and (math.sqrt(i + 268) == math.ceil(math.sqrt(i + 268))):
        print(i)
