#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_45.1.py
# Create Time: 2017年05月04日 星期四 15时30分58秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

m = 1
n = 100
total = (m + n) * (n - m + 1) // 2
print(total)
