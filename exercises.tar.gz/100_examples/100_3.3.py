#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_3.3.py
# Create Time: 2017年04月24日 星期一 17时22分52秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

import math

for num in range(0, int(math.sqrt(10001 + 100))):
    if math.ceil(math.sqrt(num * num + 168)) == math.sqrt(num * num + 168):
        if num * num > 100:
            print(num * num -100)
