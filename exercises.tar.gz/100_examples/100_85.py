#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_85.py
# Create Time: 2017年05月09日 星期二 14时18分23秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：判断一个正整数能被几个9整除
'''

if __name__ == '__main__':
    num = int(input('输入一个数: '))
    mem = 1   # 9的个数
    sum = 9
    while True:
        if sum % num == 0:
            break   # 如果能被mem个9整除就终止循环
        else:
            sum = sum * 10 + 9  # 如果不能整除就扩大10倍再加9，变成多一个9
            mem += 1    # 9的个数+1
    print('{}能被{}个9整除'.format(num, mem))
