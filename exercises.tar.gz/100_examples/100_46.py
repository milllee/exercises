#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_46.py
# Create Time: 2017年05月04日 星期四 16时02分53秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：求输入数字的平方，如果平方运算后小于 50 则退出
'''

def SQ(x):
    return x * x

print('如果输入的数的平方小于50，程序将退出')
while True:
    num = int(input('输入一个数:'))
    print('{}的平方为:{}'.format(num, SQ(num)))
    if SQ(num) > 50:
        continue
    else:
        break
