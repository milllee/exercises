#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_41.py
# Create Time: 2017年05月04日 星期四 11时36分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：模仿静态变量的用法
'''

def varfunc():
    var = 0
    var += 1
    print('var = {}'.format(var))

class Static:
    StaticVar = 5
    def func(self):
        StaticVar = 8   # 后加此行，和没加一样。。。
#        self.StaticVar = 8  # 添加self后，就是实例属性，每次调用重新初始化
        self.StaticVar += 1
        print('StaticVar = {}'.format(self.StaticVar))

if __name__ == '__main__':
    for i in range(3):
        varfunc()   # 调用函数，每次重新初始化本地变量

    print('Static.StaticVar = {}'.format(Static.StaticVar)) # 类属性
    a = Static()    # 实例化类
    for i in range(3):
        a.func()    # 调用实例中函数，打印变量，不是每次都初始化    实例属性
