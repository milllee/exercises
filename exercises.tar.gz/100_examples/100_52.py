#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_52.py
# Create Time: 2017年05月04日 星期四 18时06分05秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：使用按位或 |

程序分析：0 | 0 = 0, 0 | 1 = 1, 1 | 0 = 1, 1 | 1 = 1
'''

if __name__ == '__main__':
    a = 0o77
    b = a | 3
    print('a | b is {}'.format(b))
    b |= 7
    print('a | b is {}'.format(b))
