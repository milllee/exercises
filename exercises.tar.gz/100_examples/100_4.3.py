#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_4.3.py
# Create Time: 2017年04月25日 星期二 09时48分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

p = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
r = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

year =int(input("年:"))
month =int(input("月:"))
day =int(input("日:"))

if year % 100 == 0:
    if year % 400 == 0:
        d = r
    else:
        d = p
else:
    if year % 4 == 0:
        d = r
    else:
        d = p
days = sum(d[:(month - 1)]) + day
print('是该年的第{}天'.format(days))
