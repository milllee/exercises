#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_26.py
# Create Time: 2017年05月03日 星期三 10时33分53秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：利用递归方法求5！

程序分析：递归公式：fn = n * (n-1)!
'''

def fact(n):
    if n == 0:
        return 1
    else:
        return n * fact(n-1)

print(fact(4))
