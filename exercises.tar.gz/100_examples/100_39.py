#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_39.py
# Create Time: 2017年05月03日 星期三 17时20分14秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：有一个已经排好序的数组。现输入一个数，要求按原来的规律将它插入数组中。

程序分析：首先判断此数是否大于最后一个数，然后再考虑插入中间的数的情况，插入后此元素之后的数，依次后移一个位置
'''

L = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
print('原始列表为: {}'.format(L))
num = int(input('输入一个数:'))
L.append(num)
for i in range(1, len(L)+1):
    if L[-i] < L[-(i+1)]:
        L[-i], L[-(i+1)] = L[-(i+1)], L[-i]
    else:
        break
print('新的列表为: {}'.format(L))
