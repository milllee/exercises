#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_24.1.py
# Create Time: 2017年05月02日 星期二 16时44分53秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

from functools import reduce

L = []
a, b = 1, 2
for i in range(1, 21):
    L.append(b / a)
    a, b = b, a + b
# print(sum(L))
print(reduce(lambda x, y: x + y, L))
