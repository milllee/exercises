#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_68.py
# Create Time: 2017年05月05日 星期五 15时46分14秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：有n个整数，使其前面各数顺序向后移m个位置，最后m个数变成最前面的m个数
'''

a = [1, 2, 3, 4, 5]
m = 3

for _ in range(m):
    a.insert(0, a.pop())

print(a)
