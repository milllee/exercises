#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_20.2.py
# Create Time: 2017年04月28日 星期五 16时11分10秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

hei = 100   # 第一次高度
times = 10  # 次数
height = [] # 每次反弹高度
for i in range(1, times+1): # 这里本应该为times次，但为了求第10次弹起高度而+1，算总距离要减去最后一次
    hei /= 2
    height.append(hei)
print(height)
print('第10次弹起高度: {}'.format(height[-1]))
print('第10次落地后，一共经历的路程: {}'.format(sum(height[:-1])*2+100)) # 看清问题，第10次落地时经过多少米，所以要减去第10次弹起高度和下落距离
