#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_47.1.py
# Create Time: 2017年05月04日 星期四 16时43分03秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def exchange(a, b):
    print('第一个变量 = {}, 第二个变量 = {}'.format(a, b))
    a, b = b, a
    print('第一个变量 = {}, 第二个变量 = {}'.format(a, b))

if __name__ == '__main__':
    x = 1
    y = 8
    exchange(x, y)
