#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_43.py
# Create Time: 2017年05月04日 星期四 13时55分11秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：模仿静态变量(static)另一案例。

程序分析：演示一个python作用域使用方法
'''

class Num:
    num = 1
    def inc(self):
        self.num += 1
        print('num = {}'.format(self.num))

if __name__ == '__main__':
    num = 2
    inst = Num()
    for i in range(3):
        num += 1
        print('The num = {}'.format(num))
        inst.inc()
