#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_30.py
# Create Time: 2017年05月03日 星期三 14时03分00秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：一个5位数，判断它是不是回文数。即12321是回文数，个位与万位相同，十位与千位相同
'''

print('5位数的回文数是:')
for i in range(10000, 100000):
    L = str(i)
    if L[0] == L[-1] and L[1] == L[-2]:
        print(L, end=' ')
