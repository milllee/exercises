#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_98.py
# Create Time: 2017年05月09日 星期二 20时51分45秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：从键盘输入一个字符串，将小写字母全部转换成大写字母，然后输出到一个磁盘文件"test"中保存
'''

if __name__ == '__main__':
    str1 = input('输入字符串: ').upper()
    with open('test', 'w+') as f:
        f.write(str1)
