#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_40.1.py
# Create Time: 2017年05月04日 星期四 10时30分48秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def Reverse(List):
    L = []
    for i in range(len(List)):
        L.append(List[-1])
        List = List[:-1]
    return L

L1 = Reverse([1, 2, 3, 4, 5])
L2 = Reverse(['a', 'b', 'c', 'd', 'e'])
print(L1)
print(L2)
