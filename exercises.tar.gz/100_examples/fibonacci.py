#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: fibonacci.py
# Create Time: 2017年06月20日 星期二 10时21分27秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def Fib(n):
    a, b = 0, 1
    while n:
        a, b, n = b, a+b, n-1
        print(a)

x = int(input('输入一个数字: '))
Fib(x)
