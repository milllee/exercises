#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_13.2.py
# Create Time: 2017年04月27日 星期四 15时17分08秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

for i in range(100, 1000):
    s = str(i)
    if int(s[0]) ** 3 + int(s[1]) ** 3 + int(s[2]) ** 3 == i:
        print(i)
