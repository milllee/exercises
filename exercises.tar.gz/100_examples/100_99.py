#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_99.py
# Create Time: 2017年05月09日 星期二 20时54分07秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：有两个磁盘文件A和B,各存放一行字母,要求把这两个文件中的信息合并(按字母顺序排列), 输出到一个新文件C中
'''

if __name__ == '__main__':
    with open('test1') as f:
        a = f.read()
    with open('test2') as f:
        b = f.read()
    with open('test3', 'w+') as f:
        c = list(a + b)
        c.sort()
        s = ''.join(c).strip()
        f.write(s)
