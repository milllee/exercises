#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_55.py
# Create Time: 2017年05月04日 星期四 18时30分25秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：学习使用按位取反~。

程序分析：~0=1; ~1=0;
'''

if __name__ == '__main__':
    a = 234
    b = ~a
    print('The a\'s 1 complement is {}'.format(b))
    a = ~b
    print('The a\'s 2 complement is {}'.format(a))
