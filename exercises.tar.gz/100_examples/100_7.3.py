#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_7.3.py
# Create Time: 2017年04月25日 星期二 17时32分13秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

L = [1, 4, 7]
P = []
for i in range(len(L)):
    P.append(L[i])
print(P)
