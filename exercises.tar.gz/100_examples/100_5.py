#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_5.py
# Create Time: 2017年04月25日 星期二 14时19分38秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：输入三个整数x,y,z，请把这三个数由小到大输出。

程序分析：我们想办法把最小的数放到x上，先将x与y进行比较，如果x>y则将x与y的值进行交换，然后再用x与z进行比较，如果x>z则将x与z的值进行交换，这样能使x最小
'''

L = []
for i in range(3):
    x = int(input('第{}个数: '.format(i+1)))
    L.append(x)
L.sort()
print(L)
