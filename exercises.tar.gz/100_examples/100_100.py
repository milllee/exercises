#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_100.py
# Create Time: 2017年05月10日 星期三 15时26分59秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''列表转换为字典
'''

lista = ['a', 'b', 'c']
listb = [1, 2, 3]
d = {}
for i, j in zip(lista, listb):
    d[i] = j
print(d)
