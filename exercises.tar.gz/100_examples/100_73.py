#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_73.py
# Create Time: 2017年05月08日 星期一 14时39分37秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：反向输出一个链表
'''

if __name__ == '__main__':
    List = []
    for i in range(5):
        num = int(input('输入数字:'))
        List.append(num)
    print('反向输出链表: {}'.format(List[-1::-1]))
