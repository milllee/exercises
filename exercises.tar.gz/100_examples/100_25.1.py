#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_25.1.py
# Create Time: 2017年05月02日 星期二 17时58分35秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

from functools import reduce

s = 1
t = []
for i in range(1, 21):
    s *= i
    t.append(s)
# print(sum(t))
print(reduce(lambda x, y: x + y, t))
