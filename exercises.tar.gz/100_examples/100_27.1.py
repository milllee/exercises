#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_27.1.py
# Create Time: 2017年05月03日 星期三 10时53分32秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

S = input('输入字母:')
L = list(S)
L.reverse()
for i in range(len(L)):
    print(L[i], end='')

