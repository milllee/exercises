#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_25.5.py
# Create Time: 2017年05月03日 星期三 10时30分09秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

s = 0
for i in range(1, 21):
    r = 1
    for j in range(1, i+1):
        r *= j
    s += r

print(s)
