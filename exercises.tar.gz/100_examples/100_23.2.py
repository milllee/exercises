#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_23.2.py
# Create Time: 2017年05月02日 星期二 15时03分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def Stars(num):
    for i in range(1, num):
        print(' ' * (num - i), end='')
        for j in range(1, 2 * i):
            print('*', end='')
        print()
    
    for i in range(num, 0, -1):
        print(' ' * (num - i), end='')
        for j in range(1, 2 * i):
            print('*', end='')
        print()

Stars(17)
