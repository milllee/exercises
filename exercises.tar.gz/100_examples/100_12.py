#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_12.py
# Create Time: 2017年04月24日 星期一 14时35分54秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''素数
'''

for x in range(1, 101):
    n = 0
    for y in range(1, x+1):
        if x % y == 0:
            n = n + 1
    if n == 2 :
        print(x)
# 等同于下面代码:
for x in range(2, 101):
    for y in range(2, x-1):
        if x % y == 0:
            break
    else:
        print(x)
