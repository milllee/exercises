#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_46.2.py
# Create Time: 2017年05月04日 星期四 16时25分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def power(x):
    if x ** 2 >= 50:
        print('{}的平方为:{},不小于50，继续'.format(x, x ** 2))
    else:
        print('{}的平方为:{},小于50，退出'.format(x, x ** 2))
        quit()

while True:
    x = int(input('输入数字:'))
    power(x)
