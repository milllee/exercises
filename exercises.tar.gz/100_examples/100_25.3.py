#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_25.3.py
# Create Time: 2017年05月02日 星期二 18时07分21秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

s = 0
t = 1
for i in range(1, 21):
    t *= i
    s += t
print(s)
