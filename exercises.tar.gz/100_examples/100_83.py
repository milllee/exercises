#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_83.py
# Create Time: 2017年05月09日 星期二 11时08分42秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：求0—7所能组成的奇数个数

分析：1位数: 4个;2位数: 4x7个; 3位数: 4x8x7个; 4位数: 4x8x8x7个...; 8位数: 4x8x8x8x8x8x8x7个
'''

if __name__ == '__main__':
    sum = 4 # 1位数: 1、3、5、7
    s = 4
    for i in range(2, 9): # i为位数
        #print(sum)
        if i <= 2:
            s *= 7  # 2位数之内不能有"0"，就是7种组合
        else:
            s *= 8  # 2位数以上可以有"0", 就是8种组合
        sum += s
    print(sum)
