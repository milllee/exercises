#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_23.3.py
# Create Time: 2017年05月02日 星期二 15时16分00秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

from sys import stdout

def Stars(num):
    for i in range(num):
        for j in range(num - i -1):
            stdout.write(' ')
        for k in range(2 * i - 1):
            stdout.write('*')
        print()
    
    for i in range(num - 1):
        for j in range(i + 1):
            stdout.write(' ')
        for k in range(2 * (num - i - 2) - 1):
            stdout.write('*')
        print()

Stars(4)
