#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_14.1.py
# Create Time: 2017年04月27日 星期四 15时46分33秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def Prime(n):
    L = []
    while n > 1:
        for i in range(2, n+1):
            if n % i == 0:
                n //= i
                L.append(i)
    return L

s = int(input('输入正整数:'))
if isinstance(s, int) and s > 0:
    print(s, '=', ' * '.join([ str(x) for x in Prime(s) ]))
else:
    print('输入错误')
