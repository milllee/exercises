#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_23.1.py
# Create Time: 2017年05月02日 星期二 14时55分58秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def pic(lines):
    middle, lines = int(lines / 2), int(lines + 1)
    for i in range(1, lines+1):
        empty = abs(i - middle - 1)
        print(' ' * empty, '*' * (2 * (middle - empty) + 1))

pic(20)
