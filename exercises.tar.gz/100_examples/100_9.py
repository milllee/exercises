#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_9.py
# Create Time: 2017年04月27日 星期四 14时17分22秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''暂停一秒输出
'''

import time

myD = {'a': 1, 'b': 2}
for key in myD.keys():
    print('{} {}'.format(key, myD[key]))
    time.sleep(1)
