#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_25.2.py
# Create Time: 2017年05月02日 星期二 18时03分02秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

sum1 = 0
for i in range(1, 21):
    sum2 = 1
    while i >= 1:
        sum2 *= i
        i -= 1
    sum1 += sum2

print(sum1)
