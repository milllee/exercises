#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_71.py
# Create Time: 2017年05月08日 星期一 14时07分38秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：编写input()和output()函数输入，输出5个学生的数据记录
'''

num = 3
classes = ['语文', '数学', '英语']
student = []
for i in range(5):
    student.append(['', '', []])

def input_stu(stu):
    for i in range(num):
        stu[i][0] = input('输入学生id: ')
        stu[i][1] = input('输入学生姓名: ')
        for j in range(len(classes)):
            stu[i][2].append(int(input('输入学生' + classes[j] + '成绩: ')))

def output_stu(stu):
    for i in range(num):
        print('学号:{}姓名:{}'.format(stu[i][0], stu[i][1]))
        for j in range(len(classes)):
            print('{}: {}'.format(classes[j], stu[i][2][j]))

if __name__ == '__main__':
    input_stu(student)
    print(student)
    output_stu(student)
