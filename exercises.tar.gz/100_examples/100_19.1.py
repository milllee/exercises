#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_19.py
# Create Time: 2017年04月28日 星期五 14时00分49秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

from sys import stdout

for j in range(2, 10001):
    k = []
    n = -1      # 因数个数，出去1和本身，所以从-1开始算起
    s = j       # 测试的数赋值给另一个变量
    for i in range(1, j):
        if j % i == 0:      # 如果能被i整除，说明i是因数
            n += 1          # 因数统计增加1
            s -= i          # 测试的数不断减去自己的因数, 最终=0就是完数
            k.append(i)
    if s == 0:              # 等于0，说明这个数是完数
        print(j)            # 打印完数
        for i in range(n):      # 完数的因数有n个, 应该为n+1，但为了打印格式，最后一个因数在下面print函数打印
            stdout.write(str(k[i]) + ' +')     # 打印每个因数
            stdout.write(' ')
        print(k[n])     # 打印最后一个因数
