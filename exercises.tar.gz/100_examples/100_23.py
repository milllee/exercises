#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_23.py
# Create Time: 2017年04月28日 星期五 18时19分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

n = int(input('enter a number:'))
if n % 2 == 0:
    n += 1
for  i  in range(1, n+1, 2):
    k = (n - i) // 2
    print( ' ' * k , '*' * i)

for  p in range(n-2, 0, -2):
    o = (n - p) // 2
    print(' ' * o, '*' * p)
