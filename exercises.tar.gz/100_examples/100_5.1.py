#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_5.1.py
# Create Time: 2017年04月25日 星期二 14时22分17秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

a = [5,14,7,32,48,4,13,6,23]

for i in range(len(a)):
    for j in range(i, len(a)):
        if a[i] > a[j]:
            a[i], a[j] = a[j], a[i]
print(a)
