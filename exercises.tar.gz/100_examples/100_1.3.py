#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_1.3.py
# Create Time: 2017年04月24日 星期一 15时18分18秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

line = []
for i in range(123, 433):
    a = i//100
    b = i%100//10   
    c = i%100%10
    if (a != b) and (b != c) and (a != c) and 0<a<5 and 0<b<5 and 0<c<5:
        print(i)
        line.append(i)

print('一共{}个'.format(len(line)))
