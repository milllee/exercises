#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_mul_99.py
# Create Time: 2017年04月16日 星期日 16时48分01秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

#i = 1
#swap = 0
#while i <= 9:
#    j = 1
#    if i == swap:   # 下面一步之后，如果再次回到此处时i和swap相等，说明i没有+1
#        break
#    swap = i    # 将i的值赋给swap
#    while j <= i:
#        if j == 5 and i == 6:
#            break   # 此处break则i不会+1，此处break会导致上面break，所以跳出两层while循环
#        print('{} x {} = {:2d}'.format(j, i, i * j), end=' ')
#        j += 1
#    else:
#        print()
#        i += 1

# 下面使用简便方法--将代码放到函数里面，在需要跳出的时候直接return则跳出整个函数
def mul_99():
    i = 1
    while i <= 9:
        j = 1
        while j <= i:
            if j == 5 and i == 6:
                return
            print('{} x {} = {:2d}'.format(j, i, i * j), end=' ')
            j += 1
        else:
            print()
            i += 1

mul_99()
