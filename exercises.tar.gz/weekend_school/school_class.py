#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_class.py
# Create Time: 2017年04月16日 星期日 16时32分36秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

class People(object):
    num = 100   # 类属性
    def __init__(self, name, age, sex='male'):
        self.name = name    # 实例属性(对象属性)
        self.age = age
        self.sex = sex
        self.money = 0

xiaoming = People('xiaoming', 10)
xiaoli = People('xiaoli', 20, 'female')
print(xiaoming.name)
print(xiaoli.age)
print(xiaoming.num)     # 实例属性里没有的去类属性里找
xiaoming.num = 1000 # 增加实例属性
print(xiaoming.num)     # 实例属性有就用实例属性
People.num = 10000  # 增加类属性
print(xiaoming.num) # 自己的实例属性
print(xiaoli.num)   # 自己实例属性没有，去类属性里面找
