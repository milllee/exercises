#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: global_var.py
# Create Time: 2017年06月20日 星期日 10时06分42秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

num = 2
def autofunc():
    num = 1
    print('internal block num={}'.format(num))
    num += 1
for i in range(3):
    print('The num={}'.format(num))
    num += 1
    autofunc()
