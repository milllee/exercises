#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: homework_1.1.py
# Create Time: 2017年04月26日 星期三 16时36分58秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

import time

def F_Print(Str):
    print('-' * 25)
    print(Str.center(20))
    print('-' * 25)

if __name__ == '__main__':

    try:
        with open('.db') as db_obj:
            d = {}
            for line in db_obj:
                #d.setdefault(line.split(':')[0], line.split(':')[1].strip())
                d[line.split(':')[0]] = line.split(':')[1]
    except:
        d = {}
    
    while True:
        time.sleep(1)
        print('''        电话本:
        =================
        (N)添加
        (L)列表
        (D)删除
        (Q)退出
        ''')
        choice = input('输入选择:')
        if choice.lower() not in 'nldq':
            F_Print('输入错误')
            continue
        else:
            if choice.lower() == 'n':
                name = input('输入姓名:')
                if name and name not in d.keys():
                    phone = input('输入电话:')
                    if phone.isdigit() and (len(phone) == 3):
                        d[name] = phone
                        F_Print('保存成功')
                    else:
                        F_Print('电话必须是3位数字')
                        continue
                else:
                    F_Print('姓名错误，或已存在')
            elif choice.lower() == 'l':
                lname = input('要查谁的电话:')
                if lname in d.keys():
                    F_Print('{}的电话是{}'.format(lname, d[lname]))
                else:
                    F_Print('没有{}的电话'.format(lname))
            elif choice.lower() == 'd':
                dname = input('输入删除谁的电话:')
                if dname in d.keys():
                    del d[dname]
                    F_Print('删除成功')
                else:
                    F_Print('没有{}的电话'.format(dname))
            else:
                break
    
    with open('.db', 'w+') as db_obj:
        for key in d:
            line = '{}:{}'.format(key, d[key])
            db_obj.write(line + '\n')
