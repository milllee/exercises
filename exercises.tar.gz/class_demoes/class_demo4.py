#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: class_demo4.py
# Create Time: 2017年05月10日 星期三 10时18分12秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''内置功能(函数()加与不加的区别)
'''

class Books(object):
    def __init__(self, title, author):
        self.title = title
        self.author = author

    def __str__(self):
        return self.title

    def __repr__(self):
        return self.title

    def __call__(self):
        print('{} is written by {}'.format(self.title, self.author))

if __name__ == '__main__':
    pybook = Books('Core Python', 'Wesley')
    print(pybook)   # 不加()调用__str__()和__repr__()方法
    pybook()    # 加()调用__call__()方法
