#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: class_demo3.py
# Create Time: 2017年05月10日 星期三 10时04分08秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''
类的组合使用

1.class类的组合使用
2.手机、邮箱、QQ等是可以变化的（定义在一起），姓名不可变（单独定义）。
3.在另一个类中引用
'''

class Info(object):
    def __init__(self, phone, email, qq):
        self.phone = phone
        self.email = email
        self.qq = qq

    def get_phone(self):
        return self.phone

    def update_phone(self, new_phone):
        self.phone = new_phone
        print('手机号码已更改')

    def get_email(self):
        return self.email

class AddBook(object):
    def __init__(self, name, phone, email, qq):
        self.name = name
        self.info = Info(phone, email, qq)

if __name__ == '__main__':
    DMM = AddBook('Yangmi', '12345678', 'mm@126.com', '252343434')
    print(DMM.info.get_phone())
    DMM.info.update_phone('111111111111')
    print(DMM.info.get_phone())
    print(DMM.info.get_email())
