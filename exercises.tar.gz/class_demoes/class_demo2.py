#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: class_demo2.py
# Create Time: 2017年05月10日 星期三 09时52分07秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''父类、子类以及调用父类
'''

# 父类
class AddBook(object):
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone

    def get_phone(self):
        return self.phone

# 子类
class EmplEmail(AddBook):
    def __init__(self, nm, ph, email):
        super(EmplEmail, self).__init__(nm, ph)
        self.email = email

    def get_email(self):
        return self.email

if __name__ == '__main__':
    DMM = AddBook('Yangmi', '12345678')
    SS = AddBook('Zhengshuang', '0987654')
    print(DMM.get_phone())
    print(AddBook.get_phone(SS))
    alice = EmplEmail('Alice', '345546567', 'alice@126.com')
    print(alice.get_email(), alice.get_phone())
