#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: class_demo4.1.py
# Create Time: 2017年05月10日 星期三 10时29分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

class Number(object):
    '''Custum object
    add/radd -> +;
    sub/rsub -> -;
    mul/rmul -> *;
    div/rdiv -> /;'''

    def __init__(self, number):
        self.number = number

    def __add__(self, other):
        return self.number + other

    def __radd__(self, other):
        return self.number + other

    def __sub__(self, other):
        return self.number - other

    def __rsub__(self, other):
        return other - self.number

    def __gt__(self, other):
        if self.number > other:
            return True
        else:
            return False

    def __mul__(self, other):
        return self.number * other

    def __rmul__(self, other):
        return self.number * other

    def __truediv__(self, other):   # truediv 真正除法(值为浮点)
        if other != 0:              # 对应floordiv 扫地除(值为整数)
            return self.number / other

    def __rtruediv__(self, other):
        if self.number != 0:
            return other / self.number

if __name__ == '__main__':
    num = Number(10)
    print(num + 20)
    print(30 + num)
    print(num - 5)
    print(type(num.number))
    print(30 - num)
    print(num > 15)
    print(num * 3)
    print(num / 4)
    print(40 / num)
