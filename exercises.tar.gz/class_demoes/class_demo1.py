#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: class_demo1.py
# Create Time: 2017年05月10日 星期三 09时44分04秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''累的定义
'''

class Hotel(object):
    '''docstring for Hotel'''
    def __init__(self, room, cf=1, br=15):
        self.room = room    # 房费
        self.cf = cf        # 打折
        self.br = br        # 服务费

    def cacl_all(self, days=1):
        return (self.room * self.cf + self.br) * days

if __name__ == '__main__':
    stdroom = Hotel(200)
    big_room = Hotel(230, 0.9)  # room=230, cf=0.9
    print(stdroom.cacl_all())
    print(stdroom.cacl_all(2))
    print(big_room.cacl_all())
    print(big_room.cacl_all(3))
