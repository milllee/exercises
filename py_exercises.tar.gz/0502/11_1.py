#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 11_1.py
# Create Time: 2017年04月16日 星期日 01时54分58秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

with open('python.txt', 'w') as f:
    for i in range(1, 101):
        f.write('{}\n'.format(i))

def file_hd1(name='python.txt'):
    with open(name) as f:
        res = 0
        i = 0
        for line in f:
            i += 1
            line = line.strip()
            print('第{}行的数据为: {}'.format(line.strip(), line))
            res += int(line)

        print('这些数的和为: {}'.format(res))

if __name__ == '__main__':
    file_hd1()
