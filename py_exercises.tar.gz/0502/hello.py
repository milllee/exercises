#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: hello.py
# Create Time: 2017年04月16日 星期日 04时12分03秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

import ctypes
print('Hello, python!')
