#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 11_3.py
# Create Time: 2017年04月16日 星期日 02时36分28秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

import os

filenames = []
for a, b, files in os.walk('test'):
    if files:
        filenames.append([ file[:-4] for file in files ])

fname = 'testexam'
i = 0
for files in filenames:
    f = open(fname + str(i) + '.xls', 'w')
    for name in files:
        f.write(name[-2:] + '\t' + name[:-2] + '\n')
    f.close()
    i += 1
print('成功生成')
