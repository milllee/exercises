#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: fib_demo.py
# Create Time: 2017年04月16日 星期日 07时06分42秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

num = 2
def autofunc():
    num = 1
    print('internal block num={}'.format(num))
    num += 1
for i in range(3):
    print('The num={}'.format(num))
    num += 1
    autofunc()
