#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 11_4.py
# Create Time: 2017年04月16日 星期日 03时44分02秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

import os
perfix = 'python'
length = 2
base = 1
foramt = 'mdb'

def PadLeft(str, num, padstr):
    stringlength = len(str)
    n = num - stringlength
    if n >= 0:
        str = padstr * n + str
    return str

print('在{}目录下的文件将要被改名:'.format(os.getcwd()))
all_files = os.listdir(os.getcwd())
print([ f for f in all_files if os.path.isfile(f) ])
input = input('继续按[y]: ')
if input.lower() != 'y':
    exit()
filenames = os.listdir(os.curdir)
i = base - 1
for filename in filenames:
    i += 1
    if filename != 'rename.py' and os.path.isfile(filename):
        name = str(i)
        name = PadLeft(name, length, '0')
        t = filename.split('.')
        m = len(t)
        if format == '':
            os.rename(filename, perfix+name+'.'+t[m-1])
        else:
            if t[m-1] == format:
                os.rename(filename, perfix+name+'.'+t[m-1])
            else:
                i -= 1
    else:
        i -= 1

all_files = os.listdir(os.getcwd())
print([ f for f in all_files if os.path.isfile(f) ])
