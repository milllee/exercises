#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 18_2.py
# Create Time: 2017年04月16日 星期日 14时53分23秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

class PyQueue:
    def __init__(self, size = 20):
        self.queue = []
        self.size = size
        self.end = -1

    def setSize(self, size):
        self.size = size

    def In(self, element):
        if self.end < self.size - 1:
            self.queue.append(element)
            self.end += 1
        else:
            raise QueueException('PyQueueFull')

    def Out(self):
        if self.end != -1:
            element = self.queue[0]
            self.queue = self.queue[1:]
            self.end -= 1
            return element
        else:
            raise QueueException('PyQueueEmpty')

    def End(self):
        return self.end

    def empty(self):
        self.queue = []
        self.end = -1

    def isEmpty(self):
        if self.end == -1:
            return True
        else:
            return False

class QueueException(Exception):
    def __init__(self, data):
        self.data = data

    def __str__(self):
        return self.data

if __name__ == '__main__':
    queue = PyQueue()
    for i in range(10):
        queue.In(i)
    print(queue.End())
    for i in range(10):
        print(queue.Out())
    for i in range(20):
        queue.In(i)
    print(queue.isEmpty())
    queue.empty()
    print(queue.isEmpty())
    for i in range(20):
        print(queue.Out())
