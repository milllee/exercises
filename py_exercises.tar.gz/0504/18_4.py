#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 18_4.py
# Create Time: 2017年04月16日 星期日 15时42分25秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 

class BTree:
    def __init__(self, value):
        self.left = None
        self.data = value
        self.right = None

    def insertLeft(self, value):
        self.left = BTree(value)
        return self.left

    def insertRight(self, value):
        self.right = BTree(value)
        return self.right

    def show(self):
        print(self.data)

if __name__ == '__main__':
    Root = BTree('Root')
    A = Root.insertLeft('A')
    C = A.insertLeft('C')
    D = A.insertRight('D')
    F = D.insertLeft('F')
    G = D.insertRight('G')
    B = Root.insertRight('B')
    E = B.insertRight('E')
    Root.show()
    Root.left.show()
    Root.right.show()
#    A.left.show()
#    A.right.show()
#    D.left.show()
#    D.right.show()
#    B.right.show()
    A = Root.left
    A.left.show()
    Root.left.right.show()
