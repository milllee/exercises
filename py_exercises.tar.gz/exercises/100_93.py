#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_93.py
# Create Time: 2017年05月09日 星期二 19时42分42秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：时间函数举例3
'''

import time

if __name__ == '__main__':
    start = time.clock()
    for i in range(10000000):
        print(i)
    end = time.clock()
    print('different is {:6.3f}'.format(end - start))
