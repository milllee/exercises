#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_28.1.py
# Create Time: 2017年05月03日 星期三 11时16分12秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def Age(a, n):
    if n == 1:
        return a
    else:
        return Age(a + 2, n - 1)

print(Age(10, 5))
