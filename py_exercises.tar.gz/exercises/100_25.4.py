#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_25.4.py
# Create Time: 2017年05月02日 星期二 18时13分24秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

s = 0
l = range(1, 21)
def op(x):
    r = 1
    for i in range(1, x+1):
        r *= i
    return r
s = sum(map(op, l))
print(s)
