#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_90.py
# Create Time: 2017年04月17日 星期一 11时39分24秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：列表使用实例
'''

# list
# 新建列表
testList = [10086, '中国移动', [1, 2, 3, 4, 5]]
# 访问列表长度
print(len(testList))
# 到列表结尾
print(testList[:])
# 向列表添加元素
testList.append('I\'m new here!')
print(len(testList))
print(testList[:])
# 弹出最后一个元素
testList.pop()
print(len(testList))
print(testList)
# list comprehension
matrix = [[1, 2, 3],
[4, 5, 6],
[7, 8, 9]]
print(matrix)
print(matrix[1])
col2 = [ row[1] for row in matrix ] # get a column from a matrix
print(col2)
col2even = [ row[1] for row in matrix if row[1] % 2 == 0 ] # filter odd item(过滤掉奇数)
print(col2even)
