#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_37.1.py
# Create Time: 2017年05月03日 星期三 16时49分23秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

L = []
for i in range(10):
    L.append(input('输入一个数字:'))

L.sort()
print('排序后:')
for i in range(10):
    print(L[i], end=' ')
