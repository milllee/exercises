#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_51.py
# Create Time: 2017年05月04日 星期四 17时50分29秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：使用按位与 &

程序分析：0 & 0 = 0, 0 & 1 = 0, 1 & 0 = 0, 1 & 1 = 1
'''

if __name__ == '__main__':
    a = 0o77    # 八进制,第一个是数字"0"，第二个是字母"o"
    b = a & 3
    print('a & b = {}'.format(b))
    b &= 7
    print('a & b = {}'.format(b))
