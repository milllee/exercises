#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_5.2.py
# Create Time: 2017年04月25日 星期二 14时34分28秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

x = int(input('x:'))
y = int(input('y:'))
z = int(input('z:'))

a = {'x': x, 'y': y, 'z': z}
print('-' * 10)
for w in sorted(a, key=a.get):
    print(w, a[w])
