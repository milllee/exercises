#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_8.3.py
# Create Time: 2017年04月25日 星期二 18时16分07秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''左上三角形
'''

for i in range(1, 10):
    for j in range(i, 10):
        print("{} * {} = {:2d} ".format(j,i,i*j), end=" ")
    print()

'''右上三角形
'''

for i in range(1, 10):
    for k in range(1, i):
        print (end=" " * 12)
    for j in range(i, 10):
            print("%d * %d = %2d " % (i, j, i*j), end=" ")
    print("")

'''左下三角格式输出九九乘法表
'''

for i in range(1, 10):
    for j in range(1, i+1):
        print("%d * %d = %2d " % (i, j, i*j), end=" ")
    print ()

'''右下三角格式输出九九乘法表
'''

for i in range(1, 10):
    for k in range(1, 10-i):
        print(end=" " * 12)
    for j in range(1, i+1):
        product = i * j
        print("%d * %d = %2d " % (i, j, product), end=" ")
    print ()
