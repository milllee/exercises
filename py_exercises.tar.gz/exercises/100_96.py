#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_96.py
# Create Time: 2017年05月09日 星期二 20时40分16秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：计算字符串中子串出现的次数
'''

if __name__ == '__main__':
    str1 = input('输入一串字符: ')
    str2 = input('输入要统计的字符: ')
    n = str1.count(str2)
    print('{}出现{}次'.format(str2, n))
