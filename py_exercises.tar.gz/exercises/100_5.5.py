#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_5.5.py
# Create Time: 2017年04月25日 星期二 15时42分39秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''使用 列表 sort=，可接受参数 reverse，默认为布尔值 false，按升序排序，设置为 true 则按降序排序'''

x = int(input('x:'))
y = int(input('y:'))
z = int(input('z:'))

num = [x, y, z]
num.sort()
print('从小到大: {}'.format(num))

num.sort(reverse=True)
print('从大到小: {}'.format(num))
