#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_27.py
# Create Time: 2017年05月03日 星期三 10时46分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：利用递归函数调用方式，将所输入的5个字符，以相反顺序打印出来
'''

def Reverse(s):
    for i in range(len(s)):
        print(s[-1], end='')
        s = s[:-1]

s = input('输入字母:')
Reverse(s)
