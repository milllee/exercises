#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_8.py
# Create Time: 2017年04月25日 星期二 17时35分12秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''python-2.7版本
'''

for i in range(1, 10):
    for j in range(1, i+1):
        print "%d x %d = %2d " % (j, i, i*j),
    print

'''python-3.6版本
'''

# for i in range(1, 10):
#     for j in range(1, i+1):
#         print('{} x {} = {:2d} '.format(j, i, i*j), end=' ')
#     print('')
