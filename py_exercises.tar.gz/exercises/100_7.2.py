#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_7.2.py
# Create Time: 2017年04月25日 星期二 17时11分40秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

a = [1, 2, 3]
b = a.copy()
print(b)
