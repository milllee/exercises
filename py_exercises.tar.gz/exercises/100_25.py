#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_25.py
# Create Time: 2017年05月02日 星期二 17时40分08秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：求1+2!+3!+...+20!的和。

程序分析：此程序只是把累加变成了累乘
'''

def fact(n):
    if n == 1:
        return 1
    return n * fact(n-1)

a = 0
for i in range(1, 21):
    a += fact(i)
print(a)
