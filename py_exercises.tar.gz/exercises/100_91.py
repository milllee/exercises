#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_91.py
# Create Time: 2017年04月17日 星期一 11时49分59秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：时间函数举例1
'''

import time

if __name__ == '__main__':
    print(time.ctime(time.time()))
    print(time.asctime(time.localtime(time.time())))
    print(time.asctime(time.gmtime(time.time())))
