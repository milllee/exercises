#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_49.py
# Create Time: 2017年05月04日 星期四 17时04分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：使用lambda来创建匿名函数
'''

# 当x=10，y=20，(x > y)为False(就是0),所以Max = 0 * x + 1 * y = 20
Max = lambda x, y: (x > y) * x + (x < y) * y
Min = lambda x, y: (x > y) * y + (x < y) * x

if __name__ == '__main__':
    a = 10
    b = 20
    print('更大的数是:{}'.format(Max(a, b)))
    print('更小的数是:{}'.format(Min(a, b)))
