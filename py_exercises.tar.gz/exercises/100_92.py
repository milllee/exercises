#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_92.py
# Create Time: 2017年05月09日 星期二 19时41分16秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：时间函数举例2
'''

import time

if __name__ == '__main__':
    start = time.time()
    for i in range(3000):
        print(i)
    end = time.time()
    print(end - start)
