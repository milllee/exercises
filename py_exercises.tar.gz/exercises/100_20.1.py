#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_20.1.py
# Create Time: 2017年04月28日 星期五 16时00分07秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

tour = []   # 一共经历的距离
height = [] # 每次弹起的高度
hei = 100 # 起始高度
times = 10 # 共10次

for i in range(1, times+1):
    # 从第二次开始，落地前最高点的高度是反弹高度乘以2
    if i == 1:
        tour.append(hei)
    else:
        tour.append(2 * hei)
    hei /= 2
    height.append(hei)

print('总高度: {}'.format(sum(tour)))
print('第10次弹起高度: {}'.format(height[-1]))
