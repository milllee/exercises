#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_44.1.py
# Create Time: 2017年05月04日 星期四 14时14分20秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

x = [[12, 7, 3],
    [4, 5, 6],
    [7, 8, 9]]

y = [[5, 8, 1],
    [6, 7, 3],
    [4, 5, 9]]

z = []
for i in range(len(x)):
    z.append([])
    for j in range(len(x[i])):
        z[i].append(x[i][j] + y[i][j])
for i in range(len(x)):
    print(z[i])
