#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_48.py
# Create Time: 2017年05月04日 星期四 16时56分46秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''数字比较
'''

def compare(x, y):
    if x > y:
        print('{} 大于 {}'.format(x, y))
    elif x == y:
        print('{} 等于 {}'.format(x, y))
    else:
        print('{} 小于 {}'.format(x, y))

if __name__ == '__main__':
    one = input('第一个数:')
    two = input('第二个数:')
    compare(one, two)
