#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_87.py
# Create Time: 2017年05月09日 星期二 16时24分34秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''结构体变量传递
'''

class student:
    x = 0
    c = 0

def f(stu):
    stu.x = 20
    stu.c = 'c'

if __name__ == '__main__':
    a = student()
    a.x = 3
    a.c = 'a'
    print(a.x, a.c)
    f(a)
    print(a.x, a.c)
