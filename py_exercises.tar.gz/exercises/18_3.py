#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 18_3.py
# Create Time: 2017年05月05日 星期五 11时10分22秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

G = ['G', []]
H = ['H', []]
I = ['I', []]
K = ['K', []]
E = ['E', [G, H, I, K]]
D = ['D', []]
F = ['F', []]
A = ['A', [D, E]]
B = ['B', []]
C = ['C', [F]]
Root = ['Root', [A, B, C]]
print(Root)
