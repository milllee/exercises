#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_50.py
# Create Time: 2017年05月04日 星期四 17时13分10秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：random模块的使用
'''

import random

print('生成10到20之间的随机数')
print(random.uniform(10, 20))

print('生成10到20之间的随机整数')
print(random.randint(10, 20))

print('从指定范围，按指定基数递增的集合获取一个随机数')
print(random.randrange(0, 100, 10))

print('随机选取序列中的一项')
print(random.choice('我要学python'))

print('将列表中的顺序打乱[1, 2, 3, 4, 5]')
p = [1, 2, 3, 4, 5]
random.shuffle(p)
print(p)

print('从指定序列中随机获取指定长度的片段(非连续),sample函数不会修改原序列')
List = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
Slice = random.sample(List, 5)
print('随机选:{}'.format(Slice))
print('原序列:{}'.format(List))
