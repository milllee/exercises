#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_78.1.py
# Create Time: 2017年05月08日 星期一 17时43分07秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

import operator

person = {'li': 18, 'wang': 50, 'zhang': 20, 'sun': 22}
print(max(person.items(), key=operator.itemgetter(1))[0])
print(max(person.values()))
