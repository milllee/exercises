#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_33.py
# Create Time: 2017年05月03日 星期三 14时38分23秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：按逗号分隔列表
'''

L = [1, 2, 3, 4, 5]
print(','.join([ str(x) for x in L ]))

