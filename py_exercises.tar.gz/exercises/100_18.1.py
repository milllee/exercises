#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_18.1.py
# Create Time: 2017年04月28日 星期五 11时56分45秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

from functools import reduce

Tn = 0
Sn = []
n = int(input('n = '))
a = int(input('a = '))
for i in range(n):
    Tn += a
    a *= 10
    Sn.append(Tn)
Sn = reduce(lambda x, y: x + y, Sn)
print('计算和为: {}'.format(Sn))
