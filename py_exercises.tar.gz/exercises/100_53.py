#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_53.py
# Create Time: 2017年05月04日 星期四 18时11分08秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：使用按位异或 ^

程序分析：0 ^ 0 = 0, 0 ^ 1 = 1, 1 ^ 0 = 1, 1 ^ 1 = 0
转换成二进制，相同位置不同才为"1",相同为"0"
'''

if __name__ == '__main__':
    a = 0o77
    b = a ^ 3
    print('a ^ b = {}'.format(b))
    b ^= 7
    print('a ^ b = {}'.format(b))
