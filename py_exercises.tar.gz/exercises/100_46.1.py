#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_46.1.py
# Create Time: 2017年05月04日 星期四 16时07分13秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

while True:
    n = int(input('输入一个数:'))
    print('{}的平方为:{}'.format(n, n ** 2))
    if n ** 2 < 50:
        quit()
        #exit()
        #break
    else:
        print('继续')
