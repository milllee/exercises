#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_20.py
# Create Time: 2017年04月28日 星期五 16时37分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

sum = 0
total = 0
for i in range(1, 10):
    sum = (100 * 2) / (2 ** i)
    total += sum

tenth = 100 / (2 ** 10)
print('第10次弹起高度: {}'.format(tenth))
print('第10次落地后，一共经历的路程: {}'.format(total + 100))
