#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_68.2.py
# Create Time: 2017年05月05日 星期五 16时11分29秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

m = 3
a = [1, 2, 3, 4, 5, 6, 7]

def rotate(a, n):
    n = len(a) - n
    return a[n:] + a[:n]

b = rotate(a, m)

print(a)
print(b)
