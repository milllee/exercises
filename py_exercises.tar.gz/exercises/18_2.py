#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 18_2.py
# Create Time: 2017年05月05日 星期五 10时44分39秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

class PyQueue:
    def __init__(self, size = 20):
        self.queue = []
        self.size = size
        self.end = -1

    def setSize(self, size):
        self.size = size

    def push(self, element):
        if self.isFull():
            raise QueueException('PyQueueOverflow')
        else:
            self.queue.append(element)
            self.end += 1

    def pop(self):
        if self.isEmpty():
            raise QueueException('PyQueueUnderflow')
        else:
            element = self.queue[0]
            self.end -= 1
            del self.queue[0]
            return element

    def End(self):
        return self.end

    def empty(self):
        self.queue = []
        self.end = -1

    def isEmpty(self):
        if self.end == -1:
            return True
        else:
            return False

    def isFull(self):
        if self.end == self.size - 1:
            return True
        else:
            return False

class QueueException(Exception):
    def __init__(self, data):
        self.data = data

    def __str__(self):
        return self.data

if __name__ == '__main__':
    queue = PyQueue()
    for i in range(10):
        queue.push(i)
    print(queue.End())
    for i in range(10):
        print(queue.pop())
    for i in range(20):
        queue.push(i)
    queue.empty()
#    for i in range(10):
#        print(queue.pop())
