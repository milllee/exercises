#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_29.1.py
# Create Time: 2017年05月03日 星期三 11时49分03秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def Reverse(num, length):
    if length == 0:
        return
    else:
        print(num[length - 1], end='')
        Reverse(num, length - 1)

num = input('输入数字: ')
print('长度为: {}'.format(len(num)))
length = len(num)
print('反序为: ', end='')
Reverse(num, length)
