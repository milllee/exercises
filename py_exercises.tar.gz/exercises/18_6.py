#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 18_6.py
# Create Time: 2017年05月05日 星期五 11时47分51秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def searchGraph(graph, start, end):
    results = []
    generatePath(graph, [start], end, results)
    results.sort(key=lambda x: len(x))
    return results

def generatePath(graph, path, end, results):
    state = path[-1]
    if state == end:
        results.append(path)
    else:
        for arc in graph[state]:
            if arc not in path:
                generatePath(graph, path + [arc], end, results)

if __name__ == '__main__':
    Graph = {'A': ['B', 'C', 'D'],
            'B': ['E'],
            'C': ['D', 'F'],
            'D': ['B', 'E', 'G'],
            'E': [],
            'F': ['D', 'G'],
            'G': ['E']}

    r = searchGraph(Graph, 'A', 'D')
    print('*' * 25)
    print('     path A to D')
    print('*' * 25)
    for i in r:
        print(i)
    r = searchGraph(Graph, 'A', 'E')
    print('*' * 25)
    print('     path A to E')
    print('*' * 25)
    for i in r:
        print(i)
    r = searchGraph(Graph, 'C', 'E')
    print('*' * 25)
    print('     path C to E')
    print('*' * 25)
    for i in r:
        print(i)
