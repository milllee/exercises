#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_47.py
# Create Time: 2017年05月04日 星期四 16时34分51秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：两个变量值互换
'''

def exchange(x, y):
    x, y = y, x
    return (x, y)

if __name__ == '__main__':
    x = 1
    y = 7
    print('x = {}, y = {}'.format(x, y))
    x,y = exchange(x, y)
    print('x = {}, y = {}'.format(x, y))
