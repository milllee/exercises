#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_12.4.py
# Create Time: 2017年04月26日 星期三 14时57分26秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

def isPrime(n):
    if n <= 1:
        return False
    i = 2
    while i*i <= n:
        if n % i == 0:
            return False
        i += 1
    return True

for i in range(1, 100):
    if isPrime(i) == True:
        print(i)
