#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_72.py
# Create Time: 2017年05月08日 星期一 14时36分36秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：创建一个链表
'''

if __name__ == '__main__':
    ptr = []
    for i in range(5):
        num = int(input('输入一个数字:'))
        ptr.append(num)
    
    print(ptr)
