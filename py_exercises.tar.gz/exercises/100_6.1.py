#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_6.1.py
# Create Time: 2017年04月25日 星期二 16时18分19秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''使用递归
'''

def Fib(n):
    if n == 1 or n == 2:
        return 1
    return Fib(n-1) + Fib(n-2)

print(Fib(10))
