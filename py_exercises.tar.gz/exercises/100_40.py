#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_40.py
# Create Time: 2017年05月04日 星期四 10时28分08秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：将一个数组逆序输出。

程序分析：用第一个与最后一个交换
'''

a = [1, 2, 3, 4, 5, 6, 7]
for i in range(len(a)//2):
    a[i], a[-i - 1] = a[-i - 1], a[i]

print(a)
