#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_12.1.py
# Create Time: 2017年04月26日 星期三 11时59分47秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

from itertools import count
def isPrime(n):
    if n <= 1:
        return False
    for i in count(2):
        if i * i > n:
            return True
        if n % i == 0:
            return False

for i in range(1, 100):
    if isPrime(i) == True:
        print(i)
