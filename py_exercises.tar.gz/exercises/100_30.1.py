#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_30.1.py
# Create Time: 2017年05月03日 星期三 14时15分24秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

num = input('输入一个数字:')
mun = num[::-1]
if num == mun:
    print('{}是回文数'.format(num))
else:
    print('{}不是回文数'.format(num))
