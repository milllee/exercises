#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_10.py
# Create Time: 2017年04月27日 星期四 14时19分38秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''暂停一秒输出，并格式化当前时间
'''

import time

print(time.strftime('%Y-%m-%d %H:%M:%S'.format(time.localtime(time.time()))))
time.sleep(1)
print(time.strftime('%Y-%m-%d %H:%M:%S'.format(time.localtime(time.time()))))
