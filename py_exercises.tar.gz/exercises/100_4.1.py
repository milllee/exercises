#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_4.1.py
# Create Time: 2017年04月24日 星期一 17时59分10秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

year = int(input('年: \n'))
month = int(input('月: \n'))
day = int(input('日: \n'))

months1 = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366]
months2 = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365]

if ((year % 4 == 0) and (year % 100 != 0)) or ((year % 100 == 0) and (year % 400 == 0)):
    Dth = months1[month - 1] + day
else:
    Dth = months2[month - 1] + day
print('是该年的第{}天'.format(Dth))
