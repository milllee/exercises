#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_8.1.py
# Create Time: 2017年04月25日 星期二 17时51分22秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''python-3.6使用while循环
'''

i = 0
j = 0
while i < 9:
    i += 1
    while j < 9:
        j += 1
        print('{} x {} = {:2d} '.format(i, j, i*j), end=' ')
        if i == j:
            j = 0
            print('')
            break
