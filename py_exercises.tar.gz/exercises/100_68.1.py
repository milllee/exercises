#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_68.1.py
# Create Time: 2017年05月05日 星期五 15时53分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

from collections import deque

m = 3
a = [1, 2, 3, 4, 5]
f = deque(a)
f.rotate(m)
print(list(f))
