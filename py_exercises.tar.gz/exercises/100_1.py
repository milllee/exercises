#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_1.py
# Create Time: 2017年04月24日 星期一 14时47分06秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：有四个数字：1、2、3、4，能组成多少个互不相同且无重复数字的三位数？各是多少？

程序分析：可填在百位、十位、个位的数字都是1、2、3、4。组成所有的排列后再去 掉不满足条件的排列
'''

for i in range(1, 5):
    for j in range(1, 5):
        for k in range(1, 5):
            if i != j and i != k and j != k:
                print(i,j,k)
