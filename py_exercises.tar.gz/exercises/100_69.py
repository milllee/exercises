#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_69.py
# Create Time: 2017年05月05日 星期五 16时22分43秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：有n个人围成一圈，顺序排号。从第一个人开始报数（从1到3报数），凡报到3的人退出圈子，问最后留下的是原来第几号的那位
'''

count = int(input('Please input the count:'))
li = []
for i in range(count):
    li.append(i + 1)
print(li)
times = count // 3 + 2
count_tial = 0
for i in range(times):
    for j in range(count_tial + 1, len(li) + count_tial + 1):
        if count_tial == 2:
            li[0] = 0
        if (j - count_tial) < len(li) and (j + 1) % 3 == 0:
            li[j - count_tial] = 0
    print('set 0 li: {}'.format(li))
    count_0 = li.count(0)
    print('count_0: {}'.format(count_0))
    try:
        print('index of last 0: '.format(li.index(0, len(li) - 3, len(li))))
        count_tial = len(li) - li.index(0, len(li) - 3, len(li)) - 1
    except Exception as e:
        break
    print('count_tial: {}'.format(count_tial))
    for i in range(len(li)):
        try:
            li.remove(0)
        except:
            pass
    print('after remove 0 : {}'.format(li))
if len(li) == 2:
    print('The last is: {}'.format(li[1]))
else:
    print('The last is: {}'.format(li[0]))
print('(last li: {}'.format(li))
