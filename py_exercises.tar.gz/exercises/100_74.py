#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_74.py
# Create Time: 2017年05月08日 星期一 14时43分07秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################
'''题目：连接两个链表
'''

def List_add(i):
    List = []
    for _ in range(5):
        num = int(input('输入数字: '))
        List.append(num)
    print('第{}个列表: {}'.format(i, List))
    return List     # 用函数返回值赋值给变量只能用return，不能用print()，不然赋值为None

if __name__ == '__main__':
    List1 = List_add(1) #
    List2 = List_add(2) #
    List1.extend(List2)
    print('两个列表合并后为: {}'.format(List1))
