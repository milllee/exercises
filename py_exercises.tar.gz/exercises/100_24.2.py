#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: 100_24.2.py
# Create Time: 2017年05月02日 星期二 16时53分55秒
# Author: Miller Lee
# Email: 252343465@qq.com
###############################################

a, b = 1, 2
L = []
for i in range(1, 21):
    L.append(str(b) + '/' + str(a)) # 变成字符串类型，并用"/"号相连
    a, b = b, a + b

print('{} = {}'.format(eval('+'.join(L)), '+'.join(L)))
# 用"+"把列表中的各项相连，用eval函数计算总和，"="后边列出每项相加的算式。
