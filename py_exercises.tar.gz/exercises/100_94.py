#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: 100_94.py
# Create Time: 2017年05月09日 星期二 20时00分56秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################## 
'''题目：时间函数举例4,一个猜数游戏，判断一个人反应快慢
'''

import time
import random

if __name__ == '__main__':
    play_it = input('想玩吗? (y / n)')
    while play_it.lower().strip() == 'y':
        c = input('输入一个字符: ')
        i = random.randint(0, 2 ** 32) % 100
        print('输入一个你猜的数: ')
        start = time.time()
        a = time.time()
        guess = int(input('输入一个数: '))
        while guess != i:
            if guess < i:
                print('有点小')
                guess = int(input('输入一个数: '))
            else:
                print('有点大')
                guess = int(input('输入一个数: '))
        end = time.time()
        b = time.time()
        var = end - start
#        print(var)
        print('恭喜你答对了')
        print('你猜的数是: {}'.format(i))
        print('It took you {:6.3f} seconds'.format(var))
        if var < 15:
            print('牛逼')
        elif var < 25:
            print('将就')
        else:
            print('傻冒')
        play_it = input('还想玩吗？(y / n)')
