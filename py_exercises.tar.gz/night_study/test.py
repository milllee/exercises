#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: test.py
# Create Time: 2017年04月07日 星期五 23时04分59秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def gen():
    print('generating...')
    for i in range(10):
        x=yield i
        print('x=',x,'i=',i)

m=gen()
print("0, the return is", next(m))
print('\n')
print("1, the return is", next(m))
print('\n')
print("2,send 77, the return is", m.send(77))
print('\n')
print("4, the return is", next(m))
