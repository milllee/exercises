#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: asyncio_demo1.py
# Create Time: 2017年04月08日 星期六 08时57分14秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import asyncio

#@asyncio.coroutine
async def hello():
    print('Hello, world!')
    # 异步调用asyncio.sleep(1):
#    r = yield from asyncio.sleep(1)
    r = await asyncio.sleep(1)
    print('Hello, again!')

# 获取EventLoop:
loop = asyncio.get_event_loop()
# 执行coroutine
loop.run_until_complete(hello())
loop.close()
