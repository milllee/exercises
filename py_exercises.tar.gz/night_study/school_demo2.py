#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_demo1.py
# Create Time: 2017年04月08日 星期六 17时52分49秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import multiprocessing as mp
import time

def say(n):
    time.sleep(2)
    print 'say {}'.format(n)

p = mp.Pool(2)
#p.apply_async(say, args=(1,))
#p.apply_async(say, args=(2,))
#p.apply_async(say, args=(3,))
#p.apply_async(say, args=(4,))
#p.apply_async(say, args=(5,))
#p.map(say, [1, 2, 3, 4, 5]) # 类似内建map函数的用法，会开发多个进程并发一起执行
p.map_async(say, [1, 2, 3, 4, 5]) #简写apply_async，异步非阻塞执行
#for i in range(1, 6): # for循环形式的简写
#    p.apply_async(say, args=(i,))
p.close()
p.join()
