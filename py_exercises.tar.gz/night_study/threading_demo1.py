#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: threading_demo1.py

import threading
import time

def say():
    time.sleep(5)
    print "my func is say"
say1 = threading.Thread(target=say)
say2 = threading.Thread(target=say)
say3 = threading.Thread(target=say)
say1.start()
say2.start()
say3.start()
