#!/usr/bin.env python
# -*- coding: UTF-8 -*-
# Filename: liebiao.py

x = list(input('input 20s nums:'))
zheng = []
fu = []
for i in x[:21]:
    if i >=0:
        zheng.append(i)
    else:
        fu.append(i)

print zheng
print fu
