#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_demo6.py
# Create Time: 2017年04月08日 星期六 18时50分35秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import multiprocessing as mp
import threading

def add(n):
    n[0] += 1

n = [10]
m = mp.Manager() # 使用共享内存可使进程共享变量
m1 = m.list([10])
for i in range(10):
    p = mp.Process(target=add, args=(m1,))
    p.start()
print 'ending'
print m1 # 结果为10 ~ 20间随机数，因为共享内存使变量共享
