#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: coroutine_generater.py
# Create Time: 2017年04月07日 星期五 21时37分54秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def consumer():
    r = ''
    print('lalalalalaal')
    while True:
        n = yield r
        print('xxxxxlalalalalaal')
        if not n:
            return
        print('[CONSUMER] Consuming %s...' % n)
        r = '200 OK'
        a = 'fake 200 OK'

def produce(c):
    c.send(None)
    print('babababab')
    n = 0
    while n < 5:
        n = n + 1
        print('[PRODUCER] Producing %s...' % n)
        r = c.send(n)
        print('[PRODUCER] Consumer return: %s' % r)
    c.close()

c = consumer()
print('AaAaAaAaAa')
produce(c)
