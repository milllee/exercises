#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Filename: score.py

x = (int(input('the first class score: ')), int(input('the second score class score: ')))
if x[0] >= 60:
    if x[1] < 60:
        print 'bu kao'
    else:
        print 'pass1'
else:
    print 'does not passed'
