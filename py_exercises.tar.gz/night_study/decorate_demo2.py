#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: decorate_demo2.py
# Create Time: 2017年03月22日 星期三 04时49分06秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def abc(action):
    def mabc(fun):
        def wrapper(*args, **kwargs):
            print('开始运行。。。{}'.format(action))
            fun(*args, **kwargs)
            print('结束运行!{}'.format(action))
        return wrapper
    return mabc

@abc
def consumer():
    print('等待接受处理任务。。。')
    while True:
        data = (yield)
        print('收到任务: {}'.format(data))

@abc
def producer():
    c = consumer()
    c.next()
    for i in range(3):
        print('发送一个任务。。。任务{}'.format(i))
        c.send('任务{}'.format(i))

if __name__ == '__main__':
    producer()
