#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: decorate_demo1.py
# Create Time: 2017年03月22日 星期三 04时38分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

def abc(fun):
    def wrapper(*args, **kwargs):
        print('开始运行。。。')
        fun(*args, **kwargs)
        print('结束运行。。。')
    return wrapper

@abc
def demo_decoration(x):
    a = []
    for i in range(x):
        a.append(i)
    print(a)

@abc
def hello(name):
    print('Hello {}'.format(name))

if __name__ == '__main__':
    demo_decoration(5)
    print('')
    hello('John')
