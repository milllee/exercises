#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: my_iterator.py

class MyIterator():

    def __init__(self, x = 2, xmax = 100):
        self.__mul, self.__x = x, x
        self.__xmax = xmax

    def __iter__(self):
        return self

    def next(self):
        if self.__x and self.__x != 1:
            self.__mul *= self.__x
            if self.__mul <= self.__xmax:
                return self.__mul
            else:
                raise StopIteration
        else:
            raise StopIteration

if __name__ == '__main__':
    myiter = MyIterator()
    for i in myiter:
        print('Iteration data is: ', i)
