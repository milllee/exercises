#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_demo7.py
# Create Time: 2017年04月08日 星期六 19时10分32秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

# enumerate 和 zip的用法:
name = ['Michael', 'Jack', 'Rose']
phone = [123123123, 567567567, 890890890]

for index, value in enumerate(name): # enumerate可打印出list的索引
    print value, "===>", phone[index] # 此处value为name的value，name的index为[0,1,2]，所以phone[index]==phone[0, 1, 2]

for name_value, phone_value in zip(name, phone): # zip把两个list压缩到一起，他们有相同的index
    print name_value, "===>", phone_value
