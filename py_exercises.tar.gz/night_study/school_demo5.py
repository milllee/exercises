#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: school_demo5.py
# Create Time: 2017年04月08日 星期六 18时39分40秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

import multiprocessing as mp
import threading

def add(n):
    n[0] += 1

n = [10] # 列表可更改值，如果为数字则值是不会变的
# 通过线程更改n的值:
#for i in range(10):
#    p = threading.Thread(target=add, args=(n,))
#    p.start()
#print n # 结果为20，因为使用线程更改，线程共享进程内所有变量

# 通过进程更改变量n
for i in range(10):
    p = mp.Process(target=add, args=(n,))
    p.start()
print n # 结果为10，因为进程间不共享变量
