#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: gevent_demo1.py
# Create Time: 2017年04月07日 星期五 20时36分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

from gevent import monkey; monkey.patch_socket()
import gevent

def f(n):
    for i in range(n):
        print gevent.getcurrent(), i

g1 = gevent.spawn(f, 5)
g2 = gevent.spawn(f, 5)
g3 = gevent.spawn(f, 5)
g1.join()
g2.join()
g3.join()
