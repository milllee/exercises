#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: queue_demo1.py

import Queue

q = Queue.Queue()
q.put('11')
q.put('22')
q.put('33')

print q.qsize()
print q.get()
print q.get()
print q.get()
#print q.get()
