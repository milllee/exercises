#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: thread_lock.py

import threading
import time

# 加锁状态
#n = 0
#def add():
#    global n
#    if mu.acquire():
#        n += 1
#        time.sleep(0.0001)
#        print n, " ",
#        mu.release()
#
#mu = threading.Lock()
#
#for i in range(100):
#    p = threading.Thread(target=add)
#    p.start()

# 未加锁状态
n = 0
def add():
    global n
    n += 1
#    time.sleep(0.001)
    print n, " ",

for i in range(100):
    p = threading.Thread(target=add)
    p.start()
