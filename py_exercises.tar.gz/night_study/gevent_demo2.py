#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Filename: gevent_demo2.py
# Create Time: 2017年04月07日 星期五 20时36分15秒
# Author: Miller Lee
# Email: 252343465@qq.com
######################################################

from gevent import monkey; monkey.patch_socket()
import gevent

def f(n):
    for i in range(n):
        print gevent.getcurrent(), i
        gevent.sleep(0)

g1 = gevent.spawn(f, 500000)
g2 = gevent.spawn(f, 500000)
g3 = gevent.spawn(f, 500000)
g1.join()
g2.join()
g3.join()
