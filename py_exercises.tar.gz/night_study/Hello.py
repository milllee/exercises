#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Filename: Hello.py

class Hello(object):
    def hello(self, name='world'):
        print('Hello %s' % name)
